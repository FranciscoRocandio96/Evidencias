#include <iostream>
#include <cmath>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
using namespace std;

int getDimension(const char* name,int dim);
double** getMatriz(const char* name);
void printM(double** m,int r,int c);
double distancia(double a,double b,double c,double d);

int main(){
    // leemos centroides y puntos
    const char* nameCentroid = "centroide.txt";
    const char* namePuntos = "puntos.txt";

    double** mp = getMatriz(namePuntos);
    int mprows = getDimension(namePuntos,0);
    int mpcols = getDimension(namePuntos,1);

    double** mc = getMatriz(nameCentroid);
    int mcrows = getDimension(nameCentroid,0);
    int mccols = getDimension(nameCentroid,1);

    double distancias[mprows][2];
    double item[mcrows];
    int i=0,j;
    double tmp,min;

    // repetimos algoritmo 100 veces
    for(int w=0; w<100; w++){
        printM(mc,mcrows,mccols);
        cout<<"\n--------------------------------------";
        // calculamos distancias entre centroides y puntos
        for(int y=0; y<mprows; y++){
            for(int x=0; x<mcrows; x++){
                tmp = distancia(mp[y][0],mp[y][1],mc[x][0],mc[x][1]);
                if(x==0){
                    min=tmp;
                    i=x;
                }else{
                    if(tmp<min){
                        min=tmp;
                        i=x;
                    }
                }
            }
            distancias[y][0]=i;
            distancias[y][1]=mc[i][0];
            distancias[y][2]=mc[i][1];
        }

        // limpiamos matrices
        for(int x=0; x<mcrows; x++){
            mc[x][0]=0;
            mc[x][1]=0;
            item[x] = 0;
        }

        // sacamos promedios de las distancias mas cortas
        for(int x=0; x<mprows; x++){
            i=(int)distancias[x][0];
            mc[i][0]=mc[i][0] + distancias[x][1];
            mc[i][1]=mc[i][1] + distancias[x][2];
            item[i] = item[i] + 1;
        }

        for(int x=0; x<mcrows; x++){
            mc[x][0]=mc[x][0] / item[x];
            mc[x][1]=mc[x][1] / item[x];
        }
    }
    return 0;
}

// calcula distancia entre dos puntos
double distancia(double a,double b,double c,double d){
    double r;
    r = pow(c-a,2) + pow(d-b,2);
    return sqrt(r);
}

// obtiene dimenciones de una amtriz
int getDimension(const char* name,int dim){
    int rows=0;
    int cols=0;
    FILE *archivo;
 	char caracteres[1000];
    char * token;

 	archivo = fopen(name,"r");
 	
 	while (feof(archivo) == 0){
 		fgets(caracteres,100,archivo);
 		token = strtok(caracteres, ",");
        cols=0;
        while( token != NULL ) {
            token = strtok(NULL, ",");
            cols++;
        }
        rows++;
    }

    fclose(archivo);

    if(dim==0){
        return rows;
    }else{
        return cols;
    }
}

// obtiene matriz
double** getMatriz(const char* name){
    int rows=getDimension(name,0);
    int cols=getDimension(name,1);
    int i,j;
    FILE *archivo;
 	double** mat;
 	char caracteres[1000];
    char * token;

 	archivo = fopen(name,"r");
 	
    mat = new double*[rows];
    for(int x=0; x<rows; x++){
        mat[x] = new double[cols];
    }
    i=0;
 	while (feof(archivo) == 0){
 		fgets(caracteres,100,archivo);
 		token = strtok(caracteres, ",");
        j=0;
        while( token != NULL ) {
            mat[i][j] = atof(token);
            //printf("%s ", token );
            token = strtok(NULL, ",");
            j++;
        }    
        i++;        
    }
    fclose(archivo);
    return mat;
}

// imprime matriz
void printM(double** m,int r,int c){
    cout<<"\n";
    for(int x=0; x<r; x++){
        for(int y=0; y<c; y++){
            cout<<"\t"<<m[x][y];
        }
        cout<<"\n";
    }
}