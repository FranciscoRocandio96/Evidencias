import serial, time


arduino = serial.Serial("COM5",9600,timeout=1.0)
arduino.setDTR(False)
time.sleep(1)
arduino.flushInput()
arduino.setDTR(True)
file = open('dataSet.csv', 'a+')

for i in range(26):
    rawString = arduino.readline()
    cad=rawString.decode()[:-2]
    if(len(cad)>0):
        time.sleep(0.5)
        cad+="\n"
        file.write(cad)
        print(cad,end="")
file.close()
arduino.close()