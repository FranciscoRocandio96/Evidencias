import numpy as np


data=np.genfromtxt('dataSet.csv',delimiter=',')

X=np.matrix(data[:,0:5])
Y=np.matrix(data[:,5]).transpose()

suma = np.zeros((1,X.shape[1]))
print(suma)
for i in range(len(suma)):
    suma = suma + X[i,:]
    print(suma)


print(suma)

