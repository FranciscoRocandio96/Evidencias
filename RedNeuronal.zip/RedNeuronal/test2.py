import numpy as np
import serial, time
import red
import tkinter
from tkinter import *

abc="ABCDEFGHIJKLMNÑOPQRSTUVWXYZ"

# capa de funciones, la misma que se uso en el entrenamiento
fun = [red.sigmoid,red.sigmoid]

# recuperamos los datos que se usaron en la normalizacion
r=np.matrix(np.load("datos/rows.npy"))
Xmin=np.matrix(np.load("datos/Xmin.npy"))
Xmax=np.matrix(np.load("datos/Xmax.npy"))

# numero de capas de la red
capas=len(fun)+1

# leemos los pesos sinaptipos y las polarizaciones
resp=[[],[]]
j=0
while(j<capas-1):
    resp[0].append(np.matrix(np.load("modelo/W"+str(j)+".npy")))
    resp[1].append(np.matrix(np.load("modelo/B"+str(j)+".npy")))
    j = j+1

# inicializamos arreglos que usaremos
a=[]
As=[]
Zs=[]
for i in range(capas):
    As.append(0)
    if(i<capas-1):
        Zs.append(0)


# configuramos todo para poder leer arduino
arduino = serial.Serial("COM6",9600,timeout=1.0)
arduino.setDTR(False)
time.sleep(1)
arduino.flushInput()
arduino.setDTR(True)

class Application(tkinter.Frame):
    """ GUI """
 
    def __init__(self, master):
        """ Initialize the Frame"""
        tkinter.Frame.__init__(self, master)
        self.contador=0
        self.data=np.genfromtxt('datos/dataSet.csv',delimiter=',',dtype="float")
        self.X=np.matrix(self.data[:,0:5])
        self.Y=self.data[:,5]
        self.listindexs=np.random.permutation(self.X.shape[0])

        self.grid()
        self.create_widgets()
        self.updater()
 
    def create_widgets(self):
        
        self.button1 = tkinter.Label(self)
        self.button1.pack(anchor=CENTER)
        self.button1.config(fg="blue",    # Foreground
                    
                    font=("Verdana",80))
        self.button1["text"] = "Hola"
        self.button1.grid(row=0, column=5, rowspan=1, columnspan=2)
 
    def update_button1(self):
        rawString = arduino.readline() 
        cad=rawString.decode()[:-2] # quitamos valores basura
        if(len(cad)>0):# si el arduino nos arrojo basura no hacemos nada, de lo contrario
            # casteamos los datos
            listCad=cad.split(",")
            tmp=list(map(float, listCad))[:-1]
            i=np.matrix(tmp)
            
            # Normalizamos los datos que leimos
            iN=i-Xmin
            iN=iN/(Xmax-Xmin)

            # clasificamos la entrada con la red neuronal
            As[0] = iN.transpose()
            j=0
            while(j<capas-1):
                Zs[j] = np.dot(resp[0][j],As[j]) + resp[1][j]
                As[j+1] = fun[j](Zs[j])[0]
                j = j+1
            
            # Pasamos la respuesta de la red por la funcion SoftMax
            sumExp=np.sum(np.exp(As[j]))
            iexp=np.exp(As[j])/sumExp
            
            # Retornamos el indice del valor mas activado
            index=np.argmax(iexp)

            # imprimimos resultados
            print(iN,": ",abc[index])
            self.button1["text"]=abc[index]
        
 
    def updater(self):
        self.update_button1()
        self.after(1000, self.updater)
 
root = tkinter.Tk()
root.title("monitor")
root.geometry("500x500")
app = Application(root)
root.mainloop()


