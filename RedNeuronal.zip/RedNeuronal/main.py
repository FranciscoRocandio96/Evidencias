import numpy as np
import matplotlib.pyplot as plt

def lineal(x):
    return [x,1]

def sigmoid(x):
    return [1.0/(1.0+np.exp(-x)),x-np.power(x,2)]

def tanh(x):
    ep=np.exp(x)
    en=np.exp(-x)
    return [(ep-en)/(ep+en),1-np.power(x,2)]
    
data=np.genfromtxt('datosSeno.csv',delimiter=',')

X=np.matrix(data[:,0]).transpose()
Y=np.matrix(data[:,1]).transpose()

rows = X.shape[0]

red = [X.shape[1],30,40,Y.shape[1]]
fun = [sigmoid,sigmoid,lineal]
minimo = -1
maximo = 1
alfa = 0.1

W0 = minimo + np.random.rand(red[1],red[0]) * (maximo - minimo)
W1 = minimo + np.random.rand(red[2],red[1]) * (maximo - minimo)
W2 = minimo + np.random.rand(red[3],red[2]) * (maximo - minimo)

b0 = minimo + np.random.rand(red[1],1) * (maximo - minimo)
b1 = minimo + np.random.rand(red[2],1) * (maximo - minimo)
b2 = minimo + np.random.rand(red[3],1) * (maximo - minimo)


emedio=[]
eI=1
epocas=0
while(eI>10**(-3)):
    suma=0
    for i in range(rows):
        a0 = X[i,:].transpose()
        z0 = np.dot(W0,a0) + b0
        a1 = fun[0](z0)[0]
        z1 = np.dot(W1,a1) + b1
        a2 = fun[1](z1)[0]
        z2 = np.dot(W2,a2) + b2
        a3 = fun[2](z2)[0]     

        e = Y[i,:].transpose()-a3
        
        s2 = -2*(fun[2](a3)[1])*e
        s1 = np.diagflat(fun[1](a2)[1])*W2.transpose()*s2
        s0 = np.diagflat(fun[0](a1)[1])*W1.transpose()*s1  
        
        W2 = W2 - alfa*s2*a2.transpose()
        W1 = W1 - alfa*s1*a1.transpose()
        W0 = W0 - alfa*s0*a0.transpose()
        
        b2 = b2 - alfa*s2        
        b1 = b1 - alfa*s1        
        b0 = b0 - alfa*s0  
        
        suma = e.transpose()*e + suma
        
    emedio.append((suma/rows)[0,0]) 
    eI=emedio[epocas]
    print(eI)
    epocas=epocas+1

a=[]
test = np.linspace(0,6,200)
for i in test:
    a0 = i
    z0 = np.dot(W0,a0) + b0
    a1 = fun[0](z0)[0]
    z1 = np.dot(W1,a1) + b1
    a2 = fun[1](z1)[0]
    z2 = np.dot(W2,a2) + b2
    a3 = fun[2](z2)[0]     
    a.append(a3[0,0])

fig,graficas = plt.subplots(1,2)
graficas[0].plot(range(len(emedio)),emedio,"b-",linewidth=1)
graficas[1].plot(X,Y,"ro",linewidth=1)
graficas[1].plot(test,a,"b-",linewidth=1)
plt.show()












