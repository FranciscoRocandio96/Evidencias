function r=sigmoid(x)
  r=1./(1+exp(-x));
endfunction
