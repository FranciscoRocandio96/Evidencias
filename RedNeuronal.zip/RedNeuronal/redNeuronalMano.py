import numpy as np
import matplotlib.pyplot as plt

def lineal(x):
    return [x,np.ones((x.shape))]

def sigmoid(x):
    return [1.0/(1.0+np.exp(-x)),x-np.power(x,2)]

def tanh(x):
    ep=np.exp(x)
    en=np.exp(-x)
    return [(ep-en)/(ep+en),1-np.power(x,2)]



def redNeuronal(minimo,maximo,capas,funciones,alpha,X,Y,error):
    Ws=[]
    Bs=[]
    As=[]
    Zs=[]
    Ss=[]
    rows = X.shape[0]

    for i in range(len(capas)):
        As.append(0)
        if(i<len(capas)-1):
            #Ws.append(minimo + np.random.rand(capas[i+1],capas[i]) * (maximo - minimo))
            #Bs.append(minimo + np.random.rand(capas[i+1],1) * (maximo - minimo))
            Ws.append(np.matrix(np.load("modelo/W"+str(i)+".npy")))
            Bs.append(np.matrix(np.load("modelo/B"+str(i)+".npy")))
            print(Ws[i].shape)
            print(Bs[i].shape)
            print()
            Zs.append(0)
            Ss.append(0)
    
    emedio=[]
    eI=1
    epocas=0
    while(eI>error):
        suma=0
        for i in range(rows):
            As[0] = X[i,:].transpose()
            j=0
            while(j<len(capas)-1):
                Zs[j] = np.dot(Ws[j],As[j]) + Bs[j]
                As[j+1] = fun[j](Zs[j])[0]
                j = j+1
            
            e = Y[i,:].transpose()-As[j]
            j=j-1
            while(j>=0):
                if(j==len(capas)-2):
                    Ss[j] = -2*(fun[j](As[j+1])[1])*e
                else:
                    tmp1 = fun[j](As[j+1])[1]
                    Ss[j] = np.diagflat(tmp1)*Ws[j+1].transpose()*Ss[j+1]
                j = j-1
            
            j=0
            while(j<len(capas)-1):
                Ws[j] = Ws[j] - alpha*Ss[j]*As[j].transpose()
                Bs[j] = Bs[j] - alpha*Ss[j]        
                j = j+1
            
            suma = e.transpose()*e + suma
        emedio.append((suma/rows)[0,0]) 
        eI=emedio[epocas]
        epocas=epocas+1
        if(epocas%100==0):
            j=0
            while(j<len(red)-1):
                np.save("modelo/W"+str(j),Ws[j])
                np.save("modelo/B"+str(j),Bs[j])
                j = j+1
        print(epocas,": ",eI)
    return [emedio,Ws,Bs]
        

    
data=np.genfromtxt('dataSet.csv',delimiter=',')

X=np.matrix(data[:,0:5])
Y=np.matrix(data[:,5]).transpose()

rows = X.shape[0]

red = [X.shape[1],30,30,Y.shape[1]]
fun = [sigmoid,sigmoid,lineal]
minimo = -2
maximo = 2

resp=redNeuronal(minimo,maximo,red,fun,0.000001,X,Y,10**(-3))

