import numpy as np
import matplotlib.pyplot as plt

def lineal(x):
    return [x,1]

def sigmoid(x):
    return [1.0/(1.0+np.exp(-x)),x-np.power(x,2)]

def tanh(x):
    ep=np.exp(x)
    en=np.exp(-x)
    return [(ep-en)/(ep+en),1-np.power(x,2)]



def redNeuronal(minimo,maximo,capas,funciones,alpha,X,Y,error):
    Ws=[]
    Bs=[]
    As=[]
    Zs=[]
    Ss=[]
    rows = X.shape[0]

    for i in range(len(capas)):
        As.append(0)
        if(i<len(capas)-1):
            Ws.append(minimo + np.random.rand(capas[i+1],capas[i]) * (maximo - minimo))
            Bs.append(minimo + np.random.rand(capas[i+1],1) * (maximo - minimo))
            Zs.append(0)
            Ss.append(0)
    
    emedio=[]
    eI=1
    epocas=0
    while(eI>error):
        suma=0
        for i in range(rows):
            As[0] = X[i,:].transpose()
            j=0
            while(j<len(capas)-1):
                Zs[j] = np.dot(Ws[j],As[j]) + Bs[j]
                As[j+1] = fun[j](Zs[j])[0]
                j = j+1
            
            e = Y[i,:].transpose()-As[j]
            j=j-1
            while(j>=0):
                if(j==len(capas)-2):
                    Ss[j] = -2*(fun[j](As[j+1])[1])*e
                else:
                    tmp1 = fun[j](As[j+1])[1]
                    Ss[j] = np.diagflat(tmp1)*Ws[j+1].transpose()*Ss[j+1]
                j = j-1
            
            j=0
            while(j<len(capas)-1):
                Ws[j] = Ws[j] - alpha*Ss[j]*As[j].transpose()
                Bs[j] = Bs[j] - alpha*Ss[j]        
                j = j+1
            
            suma = e.transpose()*e + suma
            
        emedio.append((suma/rows)[0,0]) 
        eI=emedio[epocas]
        print(eI)
        epocas=epocas+1
    return [emedio,Ws,Bs]
        

    
data=np.genfromtxt('datosSeno.csv',delimiter=',')

X=np.matrix(data[:,0:4]).transpose()
Y=np.matrix(data[:,4]).transpose()

rows = X.shape[0]

red = [X.shape[1],30,Y.shape[1]]
fun = [sigmoid,lineal]
minimo = -1
maximo = 1

resp=redNeuronal(-1,1,red,fun,0.0001,X,Y,10**(-3))

a=[]
As=[]
Zs=[]
for i in range(len(red)):
    As.append(0)
    if(i<len(red)-1):
        Zs.append(0)
        
test = np.linspace(0,6,200)
for i in test:
    As[0] = i
    j=0
    while(j<len(red)-1):
        Zs[j] = np.dot(resp[1][j],As[j]) + resp[2][j]
        As[j+1] = fun[j](Zs[j])[0]
        j = j+1
    a.append(As[j][0,0])

fig,graficas = plt.subplots(1,2)
graficas[0].plot(range(len(resp[0])),resp[0],"b-",linewidth=1)
graficas[1].plot(X,Y,"ro",linewidth=1)
graficas[1].plot(test,a,"b-",linewidth=1)
plt.show()
