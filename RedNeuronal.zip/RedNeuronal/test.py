import numpy as np
import serial, time

def lineal(x):
    return [x,x/x]

def sigmoid(x):
    return [1.0/(1.0+np.exp(-x)),x-np.power(x,2)]



abc = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ"
arduino = serial.Serial("COM5",9600,timeout=1.0)
arduino.setDTR(False)
time.sleep(1)
arduino.flushInput()
arduino.setDTR(True)
fun = [sigmoid,lineal]

red=3
resp=[[],[]]
j=0
while(j<red-1):
    resp[0].append(np.matrix(np.load("modelo/W"+str(j)+".npy")))
    resp[1].append(np.matrix(np.load("modelo/B"+str(j)+".npy")))
    j = j+1


a=[]
As=[]
Zs=[]
for i in range(red):
    As.append(0)
    if(i<red-1):
        Zs.append(0)
        
test = np.linspace(0,6,200)
while(True):
    rawString = arduino.readline()
    cad=rawString.decode()[:-2]
    if(len(cad)>0):
        listCad=cad.split(",")
        tmp=list(map(float, listCad))[:-1]
        i=np.matrix(tmp)
        
        As[0] = i.transpose()
        j=0
        while(j<red-1):
            Zs[j] = np.dot(resp[0][j],As[j]) + resp[1][j]
            As[j+1] = fun[j](Zs[j])[0]
            j = j+1
        index=int(round(As[j][0,0]))
        print(i,": ",index)
