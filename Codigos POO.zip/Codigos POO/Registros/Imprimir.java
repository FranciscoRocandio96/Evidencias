package Registros;
import javax.swing.JLabel;
import java.awt.Frame;
import javax.swing.JDialog;
import java.util.LinkedList;

public class Imprimir extends JDialog{
    private LinkedList<Dulce> lista;
    private JLabel texto;

    public Imprimir(Frame owner, boolean modal,LinkedList<Dulce> aux){
        super(owner,modal);
        lista=aux;
        this.setTitle("Bienvenido");                   // colocamos titulo a la ventana
        this.setSize(500, 500);                                 // colocamos tamanio a la ventana (ancho, alto)
        this.setLocationRelativeTo(null);                       // centramos la ventana en la pantalla
        this.setLayout(null);                                   // no usamos ningun layout, solo asi podremos dar posiciones a los componentes
        this.setResizable(false);                               // hacemos que la ventana no sea redimiensionable
        texto = new JLabel();
        texto.setSize(200,50);
        texto.setLocation(0,0);

        String cad="<html>";
        for(int a=0; a<lista.size(); a++){
            cad+=lista.get(a)+"<br>";
        }
        cad+="</html>";

        texto.setText(cad);
        this.add(texto);

    }
    public void setImprimir(){
        String cad="";
        for(int a=0; a<lista.size(); a++){
            cad+=lista.get(a)+"\n";
        }
        texto.setText(cad);
    }

}
