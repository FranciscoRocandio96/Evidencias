package Registros;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Frame;
import javax.swing.JDialog;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;

public class Consultar extends JDialog implements ActionListener{
    private LinkedList<Dulce> lista;
    private JLabel texto,l_buscar;
    private JTextField buscar;
    private JButton btn;

    public Consultar(Frame owner, boolean modal,LinkedList<Dulce> aux){
        super(owner,modal);
        lista=aux;
        this.setTitle("Bienvenido");                   // colocamos titulo a la ventana
        this.setSize(500, 500);                                 // colocamos tamanio a la ventana (ancho, alto)
        this.setLocationRelativeTo(null);                       // centramos la ventana en la pantalla
        this.setLayout(null);                                   // no usamos ningun layout, solo asi podremos dar posiciones a los componentes
        this.setResizable(false);                               // hacemos que la ventana no sea redimiensionable

        buscar = new JTextField();
        texto = new JLabel();
        l_buscar = new JLabel("ID de dulce");
        btn = new JButton("Buscar");

        buscar.setSize(100,30);
        l_buscar.setSize(100,30);
        btn.setSize(100,30);
        texto.setSize(100,30);

        l_buscar.setLocation(0,0);
        buscar.setLocation(0,50);
        btn.setLocation(0,100);
        texto.setLocation(0,150);

        btn.addActionListener(this);

        this.add(buscar);
        this.add(l_buscar);
        this.add(btn);
        this.add(texto);

    }

    public void actionPerformed(ActionEvent e) {
        Dulce a = new Dulce(Integer.parseInt(buscar.getText()),"",0,0);
        int index;
        index=lista.indexOf(a);
        if(index!=-1){
            texto.setText(lista.get(index).toString());
        }else{
            texto.setText("");
        }
    }


}
