package Registros;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JDialog;
import java.util.LinkedList;
import java.awt.*;
import java.awt.event.*;

public class Principal extends JFrame implements ActionListener{
    private LinkedList<Dulce> lista;
    JButton consultar,registrar,buscar,imprimir;
    JDialog d_consultar,d_registrar,d_imprimir;

    public Principal(){
        lista = new LinkedList<Dulce>();
        init();
    }
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(registrar)){
            d_registrar.setVisible(true);
        }else if(e.getSource().equals(imprimir)){
            d_imprimir = new Imprimir(this,true,lista);
            d_imprimir.setVisible(true);
        }else if(e.getSource().equals(consultar)){
            d_consultar.setVisible(true);
        }

    }
    public void init(){
        this.setTitle("Bienvenido");                   // colocamos titulo a la ventana
        this.setSize(400, 500);                                 // colocamos tamanio a la ventana (ancho, alto)
        this.setLocationRelativeTo(null);                       // centramos la ventana en la pantalla
        this.setLayout(null);                                   // no usamos ningun layout, solo asi podremos dar posiciones a los componentes
        this.setResizable(false);                               // hacemos que la ventana no sea redimiensionable
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    // hacemos que cuando se cierre la ventana termina todo proceso

        consultar = new JButton("Consultar");
        registrar = new JButton("Registrar");
        imprimir = new JButton("Imprimir");

        d_registrar = new Registrar(this,true,lista);
        d_consultar = new Consultar(this,true,lista);


        consultar.setSize(100,30);
        registrar.setSize(100,30);
        imprimir.setSize(100,30);

        consultar.setLocation(0,0);
        registrar.setLocation(0,50);
        imprimir.setLocation(0,100);

        consultar.addActionListener(this);
        registrar.addActionListener(this);
        imprimir.addActionListener(this);

        this.add(consultar);
        this.add(registrar);
        this.add(imprimir);



    }
}
