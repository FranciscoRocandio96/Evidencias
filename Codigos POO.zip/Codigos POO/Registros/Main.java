package Registros;

public class Main{
    public static void main(String[] args){
        Principal a = new Principal();
        a.setVisible(true);
    }
}
