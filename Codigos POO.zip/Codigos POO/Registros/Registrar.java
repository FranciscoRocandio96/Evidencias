package Registros;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Frame;
import javax.swing.JDialog;
import java.util.LinkedList;
import java.awt.*;
import java.awt.event.*;

public class Registrar extends JDialog implements ActionListener{
    private LinkedList<Dulce> lista;
    private JButton    bton_regis;
    private JTextField id,nombre,precio_compra,precio_venta;
    private JLabel l_id,l_nombre,l_precio_compra,l_precio_venta;

    public Registrar(Frame owner, boolean modal,LinkedList<Dulce> aux){
        super(owner,modal);
        lista=aux;
        this.setTitle("Bienvenido");                   // colocamos titulo a la ventana
        this.setSize(400, 500);                                 // colocamos tamanio a la ventana (ancho, alto)
        this.setLocationRelativeTo(null);                       // centramos la ventana en la pantalla
        this.setLayout(null);                                   // no usamos ningun layout, solo asi podremos dar posiciones a los componentes
        this.setResizable(false);                               // hacemos que la ventana no sea redimiensionable

        bton_regis = new JButton("Registrar");
        id = new JTextField();
        nombre = new JTextField();
        precio_compra = new JTextField();
        precio_venta = new JTextField();

        l_id = new JLabel("ID");
        l_nombre = new JLabel("Nombre del dulce");
        l_precio_compra = new JLabel("Precio de compra");
        l_precio_venta = new JLabel("Precio de venta");

        bton_regis.setSize(150,30);
        id.setSize(150,30);
        nombre.setSize(150,30);
        precio_compra.setSize(150,30);
        precio_venta.setSize(150,30);

        l_id.setSize(150,30);
        l_nombre.setSize(150,30);
        l_precio_compra.setSize(150,30);
        l_precio_venta.setSize(150,30);

        int x=30;
        l_id.setLocation(0,x*0);
        id.setLocation(0,x*1);
        l_nombre.setLocation(0,x*2);
        nombre.setLocation(0,x*3);
        l_precio_compra.setLocation(0,x*4);
        precio_compra.setLocation(0,x*5);
        l_precio_venta.setLocation(0,x*6);
        precio_venta.setLocation(0,x*7);
        bton_regis.setLocation(0,250);

        bton_regis.addActionListener(this);

        this.add(bton_regis);
        this.add(id);
        this.add(nombre);
        this.add(precio_compra);
        this.add(precio_venta);
        this.add(l_id);
        this.add(l_nombre);
        this.add(l_precio_compra);
        this.add(l_precio_venta);
    }

    public void actionPerformed(ActionEvent e) {
        lista.add(new Dulce(Integer.parseInt(id.getText()),
                            nombre.getText(),
                            Float.parseFloat(precio_compra.getText()),
                            Float.parseFloat(precio_venta.getText())
        ));
        dispose();
    }
}
