package Registros;

public class Dulce{
    private int id;
    private String nombre;
    private float precio_compra;
    private float precio_venta;

    public Dulce(){

    }
    public Dulce(int a,String b,float c,float d){
        setDulce(a,b,c,d);
    }
    public void setDulce(int a,String b,float c,float d){
        id=a;
        nombre=b;
        precio_compra=c;
        precio_venta=d;
    }
    public int getId(){
        return id;
    }
    public String getNombre(){
        return nombre;
    }
    public float getPrecioCompra(){
        return precio_compra;
    }
    public float getPrecioVenta(){
        return precio_venta;
    }
    public String toString(){
        String cad="";
        cad=String.format("|%5d|%10s|%.2f|%.2f|\n",id,nombre,precio_compra,precio_venta);
        cad+="------------------------------";
        return cad;
    }
    public boolean equals(Object a){
        Dulce ref = (Dulce)a;
        if(this.getId()==ref.getId()){
            return true;
        }else{
            return false;
        }

    }
}
