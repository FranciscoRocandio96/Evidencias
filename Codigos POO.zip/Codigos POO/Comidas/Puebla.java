//Paquete
package Comidas;
//Scanner
import java.util.Scanner;
//Clase comida Poblana Hereda de Comida Mexicana
public class Puebla extends Mexicana{
    //Atributos
    private float tiempoPreparacion;
    private String color;

    //Metodos Propios
    public void engordar(){
        System.out.println("\nEngordando...");
    }

    public void preparar(){
        System.out.println("\nPreparando comida poblana");
    }

    //Metodos implementados
    public void ingresarIngredientes(){
        System.out.println("\nIngresando ingredientes");
    }

    public void comer(){
        System.out.println("\nComiendo comida puebla");
    }

    //Metodo para pedir Datos
    public void pedirDatos(){
        Scanner x = new Scanner(System.in);
        System.out.println("\nPuebla - Ingresa los datos: ");
        System.out.println("Color: ");
        color = x.nextLine();
        System.out.println("\nTiempo de Preparacion: ");
        tiempoPreparacion = x.nextFloat();

	}
    //Metodo toString
    public String toString(){
    	String cad = new String();
    	cad="\nTiempo de Preparacion: "+tiempoPreparacion+"\nColor: "+color;
    	return cad;
    }
}//clase
