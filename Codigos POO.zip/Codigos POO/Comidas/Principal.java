//Paquete
package Comidas;
//Scanner y ArrayList
import java.util.Scanner;
import java.util.ArrayList;
//Clase Principal
public class Principal{
	//Metodo main
	public static void main(String [] args){
		//Variables a usar.
		int op, tipo;

		Scanner lee = new Scanner(System.in);
		//Creacion del Arreglo de tipo Comida.
		ArrayList<Comida> arr = new ArrayList<Comida>();

		//Menu de Opciones
		while(true){
			System.out.println("\nMenu Platillos");
			System.out.println("\n1. Agregar Inicio");
			System.out.println("2. Agregar Final");
			System.out.println("3. Agregar en X");
			System.out.println("4. Eliminar Inicio");
			System.out.println("5. Eliminar por ID");
			System.out.println("6. Consultar Platillo");
			System.out.println("7. Buscar Platillo");
			System.out.println("8. Salir");
			System.out.println("\nIngresar Ingredientes: ");
			op = lee.nextInt();
			lee.nextLine();
			//Todos  los case Correspondientes al Menu de Opciones

			switch(op){
				case 1:
					tipo = menu();
					switch(tipo){
						case 1:				//Creamos un Objeto de tipo Italiana
                          Italiana tmp = new Italiana();
                          tmp.pedirDatos();
                          arr.add(0,tmp);
						break;
						case 2:				//Creamos un Objeto de tipo China
                          China tmp1 = new China();
                          tmp1.pedirDatos();
                          arr.add(0,tmp1);
						break;
						case 3:				//Creamos un Objeto de tipo Oaxaca
                  				Oaxaca tmp2= new Oaxaca();
                          tmp2.pedirDatos();
                          arr.add(0,tmp2);
						break;
						case 4:				//Creamos un Objeto de tipo Puebla
                        	Puebla tmp3=new Puebla();
                          tmp3.pedirDatos();
                          arr.add(0,tmp3);
						break;
					}
					break;

				case 2:
				tipo = menu();
					switch(tipo){
						case 1:					//Creamos un Objeto de tipo Italiana
                            Italiana tmp = new Italiana();
                            tmp.pedirDatos();
                            arr.add(tmp);
						break;
						case 2:					//Creamos un Objeto de tipo China
                            China tmp1 = new China();
                            tmp1.pedirDatos();
                            arr.add(tmp1);
						break;
						case 3:					//Creamos un Objeto de tipo Oaxaca
                            Oaxaca tmp2= new Oaxaca();
                            tmp2.pedirDatos();
                            arr.add(tmp2);
						break;
						case 4:					//Creamos un Objeto de tipo Puebla
                            Puebla tmp3=new Puebla();
                            tmp3.pedirDatos();
                            arr.add(tmp3);
						break;
					}
					break;
				case 3:
					tipo = menu();
					System.out.println("\n En que Posicion Quieres Agregar: ");
                    Scanner y2 = new Scanner(System.in);
					int pos=y2.nextInt();
					switch(tipo){

						case 1:						//Creamos un Objeto de tipo Italiana
                              Italiana tmp = new Italiana();
                              tmp.pedirDatos();
                              arr.add(pos,tmp);
						break;
						case 2:						//Creamos un Objeto de tipo China
                              China tmp1 = new China();
                              tmp1.pedirDatos();
                              arr.add(pos,tmp1);
						break;
						case 3:						//Creamos un Objeto de tipo Oaxaca
                              Oaxaca tmp2= new Oaxaca();
                              tmp2.pedirDatos();
                              arr.add(pos,tmp2);
						break;
						case 4:						//Creamos un Objeto de tipo Puebla
                              Puebla tmp3=new Puebla();
                              tmp3.pedirDatos();
                              arr.add(pos,tmp3);
						break;
					}

					break;
				case 4:
                              arr.remove(0);

					break;
				case 5:
										Comida aux1 = new Oaxaca();
                                        System.out.println("\n Indice de Comida: ");
                                        Scanner y1 = new Scanner(System.in);
                                        int id1 = y1.nextInt(); y1.nextLine();
                                        aux1.setIdComida(id1);
										int indice1=arr.indexOf(aux1);
										if(indice1 ==-1 ){
                                            System.out.println("\n Platillo No Encontrado ");
                                        }else{
                                            System.out.println(arr.remove(indice1));
																					}
					break;
				case 6:
                                        System.out.println(arr);
					break;
				case 7:
	                                    		Comida aux = new Oaxaca();
	                                        System.out.println("\n Indice de Comida: ");
	                                        Scanner y = new Scanner(System.in);
	                                        int id = y.nextInt(); y.nextLine();
	                                        aux.setIdComida(id);
					int indice=arr.indexOf(aux);
					if(indice ==-1 )
                                            System.out.println("\n Platillo No Encontrado ");
                                        else
                                            System.out.println(arr.get(indice));
					break;
				case 8:
					System.exit(0);
					break;
				default:
					System.out.println("\nOpción No Valida");
			}
		}

	}//main

	//Funcion del SubMenu
	public static int menu(){
		Scanner x = new Scanner(System.in);
		System.out.println("\nTipo de Comida: ");
		System.out.println("1. Italiana");
		System.out.println("2. China");
		System.out.println("3. Oaxaqueña");
		System.out.println("4. Poblana");
		System.out.println("\nIngrese una Opción: ");
		int c = x.nextInt();
		if( c >= 1 && c<= 4)
			return c;
		return 1;
	}

}//clase
