//Paquete
package Comidas;
//Scanner
import java.util.Scanner;
//Clase comida China que Hereda de Clase Abstracta Comida.
public class China extends Comida{

	//Atributos
	private float costo;
	private int cantIngredientes;

	//Metodos Propios
	public void preparacion(){
		System.out.println("\nPreparacion");
	}

	public void escribirReceta(){
		System.out.println("\nEscribir Receta");
	}

	//Metodos implementados
	public void ingresarIngredientes(){
		System.out.println("\nIngresando ingredientes, comida china");
	}

	public void comer(){
		System.out.println("\nComiendo comida China");
	}

	//Metodo pedir Datos
	public void pedirDatos(){
		Scanner x = new Scanner(System.in);
		System.out.println("\nChina - Ingresa los datos: ");
		setIdComida( generaId() );
		System.out.println("\nCantidad Ingredientes: ");
		cantIngredientes = x.nextInt();
		System.out.println("Costo");
		costo = x.nextFloat();
	}

	//Metodo toString
	public String toString(){
		String var = "\nComida China\nId: ";
		var += getIdComida();
		var += "\nCantidad Ingredientes: "+cantIngredientes;
		var += "\nCosto: " + costo +"\n";
		return var;
	}


}//clase
