//Paquete
package Comidas;
//Scanner
import java.util.Scanner;
//Clase Abstracta comida Mexicana que hereda de Comida.
public abstract class Mexicana extends Comida{

    //Atributos
    private String nombre;
    private int cantPlatillos;

    //Metodos Propios
    public void guisar(){
        System.out.println("\nGuisar");
    }

    public void servir(){
        System.out.println("\nServir");
    }

    //Setters y Getters
    public void setNombre(String n){
        nombre=n;
    }

     public void setCantPlatillos(int p){
        cantPlatillos=p;
    }

    public String getNombre(){
        return nombre;
    }

    public int getCantPlatillos(){
        return cantPlatillos;
    }

    //Metodo para Pedir Datos.
     public void pedirDatos(){
        Scanner x = new Scanner(System.in);
        System.out.println("\nMexicana - Ingresa los datos: ");
        setNombre(x.nextLine());
        System.out.println("\nCantidad de Platillos: ");
        setCantPlatillos(x.nextInt());

	}

    //Metodo toString
    public String toString(){
    	String cad= new String();
    	cad="\nNombre: "+nombre+"\nCantidad de Apellidos: "+cantPlatillos;
    	return cad;

    }
}//clase
