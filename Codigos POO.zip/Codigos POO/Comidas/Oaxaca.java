//Paquete
package Comidas;
//Scanner
import java.util.Scanner;
//Clase comida Oaxaqueña que hereda de Comida Mexicana.
public class Oaxaca extends Mexicana{
    //Atributos
    private String sabor, tipoEntrada;
    //Metodos Propios
    public void alimentar(){
        System.out.println("\nAlimentando...");
    }

    public void nutrir(){
        System.out.println("\nNutrir");
    }

    //Metodos implementados
    public void ingresarIngredientes(){
        System.out.println("\nIngresando ingredientes");
    }

    public void comer(){
        System.out.println("\nComiendo comida puebla");
    }

    //Setters y Getters
    public void setSabor( String s){
    	sabor=s;

    }
    public void setTipoEntrada( String t){

    	tipoEntrada=t;

    }

    public String getSabor(){

    	return sabor;
    }

    public String getTipoEntrada(){

    	return tipoEntrada;
    }

    //Metodo para pedir Datos.
     public void pedirDatos(){
        Scanner x = new Scanner(System.in);
        System.out.println("\nOaxaca - Ingresa los datos: ");
        System.out.println("\nSabor: ");
        tipoEntrada = x.nextLine();
        System.out.println("Tipo de entrada: ");
        sabor = x.nextLine();
	}

    //Metodo toString
    public String toString(){
    	String cad = new String();
    	cad="\nOAXAQUEÑA \nSabor: "+getSabor()+"\nTipo de Entarda: "+getTipoEntrada();
    	return cad;
    }
}//clase
