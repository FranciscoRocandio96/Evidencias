//Paquete
package Comidas;
//Scanner y Random
import java.util.Random;
import java.util.Scanner;

//Clase Abstracta Comida
public abstract class Comida{

    //Atributos
    private int idComida;

    //Metodos Abstractos
    public abstract void comer();
    public abstract void ingresarIngredientes();

    //Setters y Getters
    public void setIdComida(int id){
        idComida=id;
    }

    public int getIdComida(){
        return idComida;
    }

    //Metodo equals
    public boolean equals(Object o){
        Comida c = (Comida) o;
        if(c.idComida == this.idComida)
            return true;
        return false;
    }

    //Metodo para Generar el IdComida Aleatoriamente.
    public int generaId(){
        Random r = new Random();
        return r.nextInt(1000);

    }
    //Metodo para Pedir Datos.
    public void pedirDatos(){
        Scanner x = new Scanner(System.in);
        System.out.println("\nComida - Ingresa los datos: ");
        System.out.println("Id: ");
        setIdComida( x.nextInt() );


	}

    //Metodo toString
    public String toString(){
        String cad=new String();

        cad="Id: "+getIdComida();
        return cad;


    }

}//clase
