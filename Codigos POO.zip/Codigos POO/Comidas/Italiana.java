//Comida
package Comidas;
//Scanner
import java.util.Scanner;
//Clase comida Italiana que hereda de Clase Comida
public class Italiana extends Comida{
    //Atributos
    private float tiempoCoccion, porcion;

    //Metodos Propios
    public void quitarHambre(){
        System.out.println("\nQuitar hambre");
    }

    public void ingresaUtencilios(){
        System.out.println("\nUtencilios");
    }

    //Metodos implementados
    public void ingresarIngredientes(){
        System.out.println("\nIngresando ingredientes");
    }

    public void comer(){
        System.out.println("\nComiendo");
    }

    //Metodo para pedir Datos
    public void pedirDatos(){
        Scanner x = new Scanner(System.in);
        System.out.println("\nChina - Ingresa los datos: ");
        setIdComida( generaId() );
        System.out.println("\nTiempo de Coccion: ");
        tiempoCoccion = x.nextInt();
        System.out.println("Porcion: ");
        porcion = x.nextFloat();
	}

    //Metodo toString
    public String toString(){
        String var = "\nComida Italiana\nId: ";
        var += getIdComida();
        var += "\nTiempo de Coccion "+tiempoCoccion;
        var += "\nPorcion: " + porcion +"\n";
        return var;

	}

}//clase
