//Importamos las clases necesarias.
import java.util.Scanner;

//Creamos la clase principal
public class Fecha{
	//Creamos los Atributos
	private int dia,mes,anio;
	//Creamos los Metodos

	//Pedir datos
	public void setFecha(){
		Scanner dato = new Scanner(System.in);
		System.out.print("\n Ingresa el dia: ");
		dia=dato.nextInt();
		System.out.print("\n Ingresa el mes: ");
		mes=dato.nextInt();
		System.out.print("\n Ingresa el anio: ");
		anio=dato.nextInt();
	}//setFecha

	//Metodo para Colocar la fecha en Cadena de caracteres.
	public Fecha getFechaString(){
		Fecha y = new Fecha();
		if(dia<=31&&dia>=1&&mes>=1&&mes<13){
			if(mes==1)
				System.out.print("\n " +dia +" de Enero del "+anio);
			if(mes==2)
				System.out.print("\n " +dia +" de Febrero del "+anio);
			if(mes==3)
				System.out.print("\n " +dia +" de Marzo del "+anio);
			if(mes==4)
				System.out.print("\n " +dia +" de Abril del "+anio);
			if(mes==5)
				System.out.print("\n " +dia +" de Mayo del "+anio);
			if(mes==6)
				System.out.print("\n " +dia +" de Junio del "+anio);
			if(mes==7)
				System.out.print("\n " +dia +" de Julio del "+anio);
			if(mes==8)
				System.out.print("\n " +dia +" de Agosto del "+anio);
			if(mes==9)
				System.out.print("\n " +dia +" de Septiembre del "+anio);
			if(mes==10)
				System.out.print("\n " +dia +" de Octubre del "+anio);
			if(mes==11)
				System.out.print("\n " +dia +" de Noviembre del "+anio);
			if(mes==12)
				System.out.print("\n " +dia +" de Diciembre del "+anio);
		}
		else{
			System.out.print("\n No ingresaste un meses o dia existente! \n Por favor vuelve a ingresar los datos correctamente\n");
			y.setFecha();
			y.getFechaString();
			y.toString();
		}

		return this;
	}//getFechaString

	//Metodo toString.
	public String toString(){
		String fecha= new String();
		if(dia<=31&&dia>=1&&mes>=1&&mes<13){
		fecha= "\n " +dia +"/" +mes+"/"+anio;
		System.out.print("\n " +fecha);
		}
		return fecha;
	}//toString

	//Creamos la clase del metodo main.
	public static void main (String [] args){

				//Creamos un Objeto de la clase
        Fecha x = new Fecha();
				//Pedimos los Datos e Imprimimos
        x.setFecha();
        x.getFechaString();
				x.toString();

    }//main


}//Fecha
