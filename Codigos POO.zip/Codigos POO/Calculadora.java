/*Importamos la clase Scanner el cual nos provee metodos
para poder leer valores de entrada de varios tipos de datos.
*/
import java.util.Scanner;

//Creamos la clase principal del programa.
public class Calculadora{
	//Creamos la clase del metodo main.
	public static void main(String[] arg){
		//Creamos el objeto de tipo Scanner para la captura de datos.
		//Creamos las variables del tipo de dato a utilizar.
		Scanner lee = new Scanner(System.in);
		double x,y,r;
		int opc;
		//Creamos un bucle do{}()while para que se repita hasta que se ingrese la opcion salir.
		do{
		System.out.println("\n \t CALCULADORA \n");
		System.out.println("\n 1.- Suma. \n");
		System.out.println("\n 2.- Resta.\n");
		System.out.println("\n 3.- Multiplicacion.\n");
		System.out.println("\n 4.- Division.\n");
		System.out.println("\n 5.- Salir\n");
		System.out.println("\n \t Selecciona una Opcion: ");
		opc = lee.nextInt();

		// Usamos un switch para que realice la operacion indicada deacuerdo a la opcion seleccionada.
		switch(opc){

			case 1:
			System.out.println("\n Ingresa X: ");
			x = lee.nextDouble();
			System.out.println("\n Ingresa Y: ");
			y = lee.nextDouble();

			r = x+y;
			System.out.println("\n El resultado es: "+r);
			break;

			case 2:
			System.out.println("\n Ingresa X: ");
			x = lee.nextDouble();
			System.out.println("\n Ingresa Y: ");
			y = lee.nextDouble();

			r = x-y;
			System.out.println("\n El resultado es: "+r);
			break;

			case 3:
			System.out.println("\n Ingresa X: ");
			x = lee.nextDouble();
			System.out.println("\n Ingresa Y: ");
			y = lee.nextDouble();

			r = x*y;
			System.out.println("\n El resultado es: "+r);
			break;

			case 4:
			System.out.println("\n Ingresa X: ");
			x = lee.nextDouble();
			System.out.println("\n Ingresa Y: ");
			y = lee.nextDouble();

			r = x/y;
			System.out.println("\n El resultado es: "+r);
			break;

			case 5:
			System.out.println("\n Usted a Salido.");
			System.exit(0);
			break;

			default:
			System.out.println("\n Opcion Incorrecta.");
			break;

		}//sw

	}while(opc!=5);// hasta que se seleccione la opcion 5 repite.

	}//main
}
