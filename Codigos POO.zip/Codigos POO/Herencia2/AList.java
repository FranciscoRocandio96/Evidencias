//Paquete
package Herencia2;
//ArrayList
import java.util.ArrayList;
  //clase ArrayList
public class AList{
  //Metodo main
  public static void main ( String[] args ){

    ArrayList<Doctor> arr = new ArrayList<Doctor>();
    arr.add(new Doctor (1.5f) );
    arr.add(new Doctor (3.5f) );
    Doctor x = new Doctor(4.5f);
    arr.add(x);// Agrega

    arr.get(1).pedirDatos();

    for(int i=0; i<5; i++){
      arr.add(i,new Doctor(i) );
    }
    System.out.println("\n Doctores Registrados: ");
    for(int i=0; i<arr.size(); i++){
      System.out.println(arr.get(i) );
    }

    Doctor y = new Doctor(9.0f);
    y.pedirDatos();
    arr.set(  3,y );// Intercambia

    arr.remove(2);// Remueve o Quita
    System.out.println(" ArrayList: \n"+arr);
    arr.remove(y);
    System.out.println(" ArrayList: \n"+arr);

    arr.remove(5);
    int pos = arr.indexOf(x);
    System.out.println("\n Indice: "+pos);

    pos = arr.lastIndexOf(x);
    System.out.println("\n Indice Ultimo: "+pos);

    Doctor z = new Doctor(13.0f);
    z.setNumCedula(123);
    pos = arr.indexOf(z);
    System.out.println("\n Doctor Z en: "+pos);

  }//main
}//clase
