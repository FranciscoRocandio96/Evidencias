//Paquete
package Herencia2;

//Clase Profesor que Hereda de Clase Trabajador
public class Profesor extends Trabajador{

  // Metodos
  public void calcSueldo(){

  }
	public void pedirDatos(){

  }


}
