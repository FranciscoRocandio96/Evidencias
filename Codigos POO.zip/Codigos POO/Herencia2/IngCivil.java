//Paquete
package Herencia2;

//Clase IngenieroCivil que Hereda de Clase Trabajador
public class IngCivil extends Trabajador{

  //Metodos
  public void calcSueldo(){

  }
	public void pedirDatos(){

  }

}//IngCivil
