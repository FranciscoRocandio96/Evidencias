//Paquete
package Herencia2;
//Scanner
import java.util.Scanner;
//Clase Doctor que Hereda de clase Trabajador
public class Doctor extends Trabajador {
	//Atributos
	private float extras;
	private int numCedula;
	//Contructor
	public Doctor(float x){
		//super("No name", 8.7f);
		//super();				//Invoca al constructor
						//padre que no recibe parametros
		System.out.println("Contructor DOCTOR");
		extras = x;

	}

	//Setters y Getters
	public void setNumCedula(int nc){
		numCedula = nc;
	}
	public int getNumCedula(){
		return numCedula;
	}

	//Metodo calcSueldo
	public void calcSueldo(){
		setSueldo( getCostoServ() * numServ );
		// sueldo = costoServ * numServ;
	}

	//Metodo para Pedir Datos
	public void pedirDatos(){
		Scanner x = new Scanner(System.in);
		System.out.println("\nIngresa los datos: \nNombre: ");
		setNombre( x.nextLine() );
		System.out.println("Numero de consultas: ");
		setNumServ( x.nextInt() );
		System.out.println("Costo de consulta: ");
		setCostoServ( x.nextFloat() );
		System.out.println("Ingreso extra: ");
		extras = x.nextFloat();
		System.out.println("Ingreso Numero de Cedula: ");
		numCedula = x.nextInt();
	}
	//Metodos
	public void cantar(){
		System.out.println("aSDSAD ASDSAD ASDASD");
	}

	//Metodo equeals
	public boolean equals(Object ob){
		Doctor x = (Doctor) ob;
		if( x.numCedula == this.numCedula )
			return true;
		return false;
		//return x.getNombre().equals( this.getNombre() );

	}

	//metodo toString
	public String toString(){
		String cadena = "\n Doctor: "+numCedula;
		cadena += "\n Nombre: "+getNombre();
		cadena += "\n Ingreso Extra: "+extras+"\n";
		return cadena;
	}//toString

}//clase
