//Paquete
package Herencia2;
//Clase Arreglos
public class Arreglos{
	//Metodo main
	public static void main( String[] args ){


		// 1. Crear arreglo (referencias a doctor)
		Doctor[] arr1 = new Doctor[3];
		// 2. Crear objeto para indice en el arreglo
		arr1[0] = new Doctor(6f);
		// 3. Invocar metodo
		arr1[0].cantar();

		arr1[1] = arr1[0];

		//Crear un objeto de Doctor
		Doctor otro = new Doctor(5f);
		arr1[2] = otro;



		//Crea un arreglo de Profesores
		Profesor[] arr2 = new Profesor[50];
		for( int i=0; i<50; i++) {
			arr2[i] = new Profesor();
			System.out.println( arr2[i].toString() );
		}

		//Crea un arreglo de Trabajador
		Trabajador[] arr3 = new Trabajador[58];

		for( int i=0; i<50; i++)
			arr3[i] = arr2[i];

		for( int i=0; i<3; i++)
			arr3[ (50+i) ] = arr1[i];

		for( int i=0; i<5; i++)
			arr3[ (53+i) ] = new IngCivil();

			//Imprimimos los Arreglos
		for( int i=0; i<58; i++)
		{
			if( arr3[i] instanceof Doctor )
				System.out.println("Objeto:  "+ i +"\t Doctor");
			if( arr3[i] instanceof Profesor )
				System.out.println("Objeto:  "+ i +"\t Profesor");
			if( arr3[i] instanceof IngCivil )
				System.out.println("Objeto:  "+ i +"\t IngCivil");
		}


	}

}//clase
