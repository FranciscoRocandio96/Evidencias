//Paquete
package Herencia2;
//Clase abstractas de Trbajador
public abstract class Trabajador{
	//Atributos
	private String nombre;
	private float sueldo, costoServ;
	protected int numServ;

	//constructor
	public Trabajador(){
		System.out.println("\nContructor TRABAJADOR");
	}
	//constructor
	public Trabajador( String n ){
		nombre = n;
	}
	//Contructor
	public Trabajador( String n, float c){
		this(n);
		costoServ = c;
	}

	//Los metodos abstractos
	public abstract void calcSueldo();
	public abstract void pedirDatos();

	//Metodo toString
	public String toString(){
		String r = "\n Trabajador : \n";
		r += "\t Sueldo: " + this.getSueldo() + "\n";
		return r;
	}

	// Metodos SET-GET
	public void setNombre( String n ){
		nombre = n;
	}

	public void setSueldo( float sueldo ){
		this.sueldo = sueldo;
	}

	public void setCostoServ( float c ){
		costoServ = c;
	}

	public void setNumServ( int n ){
		numServ = n;
	}

	public String getNombre(){
		return nombre;
	}

	public float getSueldo(){
		return sueldo;
	}

	public float getCostoServ(){
		return costoServ;
	}

	public int getNumServ(){
		return numServ;
	}

}//clase
