package Herencia2;

public class Principal{

	public static void main( String[] args ){

		//Trabajador t = new Trabajador();
		//No se pueden crear objetos de clases abstractas

		/*Doctor d = new Doctor(6.8f);
		d.pedirDatos();
		d.calcSueldo();
		System.out.println( d.toString() );
		*/

		Trabajador obj1 = new Doctor( 6.8f );  // Polimorfismo

		System.out.println( obj1 );
		obj1.pedirDatos();
		obj1.calcSueldo();
		System.out.println( obj1 );
		//obj1.cantar();

		if( obj1 instanceof Trabajador )// Pertenece a
			System.out.println("Obj1 es un trabajador");

		if( obj1 instanceof Doctor ){
			System.out.println("Obj1 es un doctor");
			((Doctor)obj1).cantar(); // cambio de tipo de dato
		}

		if( obj1 instanceof Object )
			System.out.println("Obj1 es un objeto");

			Doctor uno = new Doctor(3.6f);
			uno.pedirDatos();
			Doctor dos = new Doctor(5.1f);
			dos.pedirDatos();

			if (uno.equals(dos))
			System.out.println("Doctores Iguales.");
			else
			System.out.println("Doctores Diferentes.");

	}//main

}//clase
