//Paquete
package Composicion_Auto;
//Scanner
import java.util.Scanner;
//Clase Llantas
public class Llantas{
	//Atributos
	private int tamanio;
	private String marca, color, tipo;
	//Metodo para pedirDatos
	public void obtenerDatos(){
		Scanner lee = new Scanner(System.in);
		System.out.println("Ingresa tamano de llanta: ");
		tamanio = lee.nextInt();    lee.nextLine();
		System.out.println("Marca de la llanta: ");
		marca = lee.nextLine();
		System.out.println("Color: ");
		color = lee.nextLine();
		System.out.println("Tipo: ");
		tipo = lee.nextLine();

	}//obt
		//Metodo toString
		public String toString(){
		String r;
		r = "\n Llanta: \n\t Tamano: " + tamanio;
		r += "\n\t Marca: " + marca + "\n\t Color: ";
		r += color + "\n\t Tipo: " + tipo + "\n";
		return r;
	}//toS

	//Metodo para Modificar datos de Llanta
	public void modificarTamanio(){
		Scanner lee = new Scanner(System.in);
		System.out.println("Tamano actual: "+tamanio);
		System.out.println("Ingrese nuevo tamano: ");
		tamanio = lee.nextInt();	//numero
		lee.nextLine();				//enter
	}//mod

}//clase
