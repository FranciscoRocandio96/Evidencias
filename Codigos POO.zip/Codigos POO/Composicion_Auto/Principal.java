//Paquete
package Composicion_Auto;
//Clase Principal
public class Principal{
	//Metodo main
	public static void main (String[] args){
		//Creamos un objeto de Auto
		Auto obj = new Auto();
		//Invocamos los metodos creados
		obj.obtenerDatos();
		obj.modificarModelo();
		obj.imprimirAuto();
		//Creamos un segundo Objeto de Auto e invocamos los otros metodos creados
		Auto obj2 = new Auto();
		obj2.crearLlanta();
		obj2.imprimirAuto();
	}//main

}//clase
