//Paquete
package Composicion_Auto;
//Scanner
import java.util.Scanner;
//Clase Auto
public class Auto{
	//Atributos
	private String color, tipo;
	private int modelo;
	//Variables de Composicion
	private Llantas llanta1;
	//Arreglo de Llantas
	private Llantas[] llantas1;

		//Constructor
    public Auto(){
			//Inicializamos los indices de los Arreglo
		llantas1 = new Llantas[4];
		llantas1[0] = new Llantas();
		llantas1[1] = new Llantas();
		llantas1[2] = new Llantas();
		llantas1[3] = new Llantas();
		//llantas1[4] = new Llantas();
    }
	//Metodo para crear Llantas
	public void crearLlanta(){
        llanta1 = new Llantas();//Composicion

	}//RELACION ENTRE OBJETOS

		//Metodo para pedirDatos
		public void obtenerDatos(){
		Scanner lee = new Scanner(System.in);
		System.out.println("Ingresa tipo de auto: ");
		tipo = lee.nextLine();
		System.out.println("Modelo del auto: ");
		modelo = lee.nextInt();
		lee.nextLine();
		System.out.println("Color del auto: ");
		color = lee.nextLine();
		//Pedimos los datos de de las Llantas
		for(int i=0;i<4; i++){
			llantas1[i].obtenerDatos();
		}


	}//obt


	public void imprimirAuto(){
		System.out.println("\n\t Auto: \n");
		System.out.println(" Tipo: " + tipo );
		System.out.println(" Color: " + color);
		System.out.println(" Modelo: " + modelo);
		//Imprimimos los datos de las llantas
		for(int i=0;i<4; i++){
			System.out.println( llantas1[i] );
		}
		  //		System.out.println( llanta1.toString() );	//Es lo mismo

	}//imp

	public void modificarModelo(){
		Scanner lee = new Scanner(System.in);
		System.out.println("Modelo actual: "+ modelo);
		System.out.println("Ingrese nuevo modelo: ");
		modelo = lee.nextInt();		//numero
		lee.nextLine();				//enter
	}//mod

}//clase
