package Stark;
import java.util.Scanner;

public class Reactor{

  private float paladio;
  private float costo;
  private float peso;

  public  void pedirDatos(){
    Scanner lee = new Scanner(System.in);
    System.out.println("\n Datos de Reactor ARC!");

    System.out.println("\n Ingresa Cantidad de Paladio: ");
    paladio = lee.nextFloat();

    System.out.println("\n Ingresa Costo $: ");
    costo = lee.nextFloat();

    System.out.println("\n Ingresa Peso: ");
    peso = lee.nextFloat();

  }//pedirDatos

  //Metodo toString
  public String toString(){
    String cad = "\n Reactor ARC: ";
    cad += "\n Paladio: "+paladio;
    cad += "\n Costo: "+costo;
    cad += "\n Peso: "+peso;
    return cad;
  }




}//Reactor
