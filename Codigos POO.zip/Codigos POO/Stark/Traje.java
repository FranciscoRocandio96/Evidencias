package Stark;
import java.util.Scanner;

public class Traje{
  private float peso;
  private float version;
  private String color;

  public  void pedirDatos(){
    Scanner lee = new Scanner(System.in);
    System.out.println("\n Datos del Traje de Tony");

    System.out.println("\n Ingresa el Peso: ");
    peso = lee.nextFloat();

    System.out.println("\n Ingresa la Version: ");
    version = lee.nextFloat();

    System.out.println("\n Ingresa el Color: ");
    color = lee.nextLine();
    color = lee.nextLine();

  }//pedirDatos

  //Metodo toString
  public String toString(){
    String cad = "\n Traje: ";
    cad += "\n Peso: "+peso;
    cad += "\n Version: "+version;
    cad += "\n Color: "+color;
    return cad;
  }

}//Traje
