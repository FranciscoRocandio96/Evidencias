package Stark;

public class Principal{
  public static void main(String[] args){


    System.out.println("\n");
    System.out.println("Programa que muestra nos muestra la Relacion entre clases !!!");
    System.out.println("Tony Stark esta Compuesto por el Reactor ARC !!");
    System.out.println("Tony Stark esta Asociado a un Traje !!");



    //Creamos el objeto de Tony
    Tony obj = new Tony();
    obj.pedirDatos();

    //Creamos un objeto de Traje
    Traje obj2 = new Traje();
    obj2.pedirDatos();

    //Metodo set Para la Asocioacion
    obj.setTraje(obj2);
    System.out.println(obj);


  }
}//Principal
