package Stark;
import java.util.Scanner;

public class Tony{

  private float altura;
  private float peso;
  private int edad;
  private Reactor arc;
  private Traje tra;


  //Composicion
  public Tony(){
    arc = new Reactor();
  }

  //Asociacion
  public void setTraje( Traje t ){
    tra = t;
  }

  public  void pedirDatos(){
    Scanner lee = new Scanner(System.in);
    System.out.println("\n Datos de Tony Stark !");

    System.out.println("\n Ingresa Edad: ");
    edad = lee.nextInt();
    System.out.println("\n Ingresa Peso: ");
    peso = lee.nextFloat();
    System.out.println("\n Ingresa Altura: ");
    altura = lee.nextFloat();
    arc.pedirDatos();
  }//pedirDatos


    //Metodo toString
    public String toString(){
      String cad = "\n Tony Stark: ";
      cad += "\n Edad: "+edad;
      cad += "\n Peso: "+peso;
      cad += "\n Altura: "+altura;
      cad += arc.toString();
      cad += tra.toString();
      return cad;
    }

}//Tony
