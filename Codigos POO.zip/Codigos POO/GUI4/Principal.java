//Paquete
package GUI4;
//Clase Principal
public class Principal{
  //Metodo main
  public static void main(String[] args){
    //Creamos un objeto de Ventana
    Ventana ve = new Ventana();
    //Hacemos visible la Ventana
    ve.setVisible(true);


  }//main
 
}//Principal
