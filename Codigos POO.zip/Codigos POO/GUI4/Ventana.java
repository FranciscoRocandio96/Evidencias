//Paquete
package GUI4;
//Componentes para la ventana y Eventos de la misma
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

//Clase Ventana que hereda JFrame
public class Ventana extends JFrame{

  //Atributos y Componenetes
  JLabel etiqueta1;
  JButton boton1,boton2;
  JTextField texto;
  JPanel panel;
  JLabel et,et2et3;

  //Constructor
  public Ventana(){
    //Titulo
    setTitle("Principal");
    //Tamaño
    setSize(700,750);
    //Color
    getContentPane().setBackground(Color.GREEN);
    //Colocamos null, para nosotros colocar nuestros componenets como querramos
    setLayout(null);
    //Desabilitamos que se cierre la ventana.
    setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

    //Invocamos metodo donde se inicializan los Componenetes
    initComponents();

  //CLASE ANONIMA - Boton Salir
  boton1.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent ev){
        //Crea una Ventana igual a la que se Creo
        Ventana ve2 = new Ventana();
        ve2.setBounds(800,50,700,750);

      }//boton1

  });

  //CLASE ANONIMA - Boton
  boton2.addActionListener(new ActionListener(){

    public void actionPerformed(ActionEvent ev){
      //Enviamos un msj Ingresa una Contraseña
      JOptionPane.showInputDialog(null,"Contraseña");
      //Guardamos esa comtraseña
      String cad = JOptionPane.showInputDialog("Contraseña");
      //Tenemos definida nuestra contraseña
      String contra = "ICO-2017";
      //Compramos si la contraseña ingresada es igual a la que tenemos definida
      if(contra.equals(cad)){
        //En caso de ser igual salimos del programa
      System.exit(0);
    }
    else{
      //De lo contrario enviamos un msj Incorrecto
      JOptionPane.showMessageDialog(null,"Incorrecto");
    }
    }//boton2

  });//boton2



  }//Ventana



  //InitComponents
  public void initComponents(){
    //Inicializamos todos los componenetes
  etiqueta1 = new JLabel("Texto");
  boton1 = new JButton("Salir");
  texto = new JTextField(30);
  boton2 = new JButton("Boton");

  // Creamos un objeto de tipo Dibujo
  Canvas Db = new Dibujo();
  //Colocamos el color del Lienso
  Db.setBackground(Color.PINK);
  //Colocamos coordenadas y medidas del mismo
  Db.setBounds(50,150,550,450);

  //Agregamos los Componenetes al panel
  add(etiqueta1);
  add(boton1);
  add(boton2);
  add(texto);
  //Agregamos al Centro el Objeto de Dibujo
  add("Center",Db);

  //Damos las coordenadas y tamaño de los Componenetes
  etiqueta1.setBounds(50,50,50,30);
  texto.setBounds(50,100,300,30);
  boton1.setBounds(500,620,90,30);
  boton2.setBounds(50,620,90,30);

  }

  //Creamos una clase Interna llamada Dibujo que Hereda de Canvas
  public class Dibujo extends Canvas{
    //Metodo paint recibe un objeto de Graphics
    public void paint(Graphics g){
      //Colocamos un color a las figuras
      g.setColor(Color.BLACK);
      //damos las medidas del Rectangulo
      g.fillRect(100,300,100,120);
      //Damoslas medidas del Ovalo
      g.fillOval(100,50,100,150);

      //Creamos arreglos con las coordenadas para el poligono
      int[] x = {300,400,300};
      int[] y = {300,420,420};
      //Damos las medidas
      g.fillPolygon(x,y,3);
      //Creamos arreglos con las coordenadas para el poligono
      int[] i = {300,300,400,400,350};
      int[] j = {100,200,200,100,50};
      //Damos las medidas
      g.fillPolygon(i,j,5);
    }//paint

    }//DCanvas

}//Ventana
