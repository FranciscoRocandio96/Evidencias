package Aleatorios;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.awt.*;


    //La Clase Ventana que Hereda de JFrame
public class Ventana extends JFrame{

      private JLabel eti;
      private JTextField txt;
      private JButton salir,generar;




        //Creamos el Constructor
        public Ventana(){


            this.setTitle("Numeros Aleatorios");
            this.setBounds(100,100,600,400);
            this.setLayout(null);
            initComponets();
            this.setResizable(false);
            this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

            generar.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ev){
                  String cad = txt.getText();
                  int cont=0;
          //Verificamos que no ingrese Vacio o Letras
          if( cad ==null || cad.equals("") ){
                 JOptionPane.showMessageDialog(null," Verifica los datos Ingresa un Numero.");
                 txt.setText("");
          }

          int num = Integer.parseInt(cad);
           int lista[] = new int[num];
           int lista_sin_repetir[] = new int[num];

           //Generamos los Numeros Aleatorios
          System.out.println("\n Arreglo Generado: ");
          for(int x=0; x<num; x++){
            int aux = (int)(Math.random()*(80-50+1)+50);
            lista[x]=aux;
            //aleatorio2[x]=aux;
          System.out.print(" "+lista[x]);
          }

          //Verificamos los elementos Repetidos del arreglo
          int index;
          int elementos_insertados = 0;

          for(int x=0; x < lista.length; x++){
            index=-1;
              for(int y=0; y < elementos_insertados; y++){
                if( lista_sin_repetir[y] == lista[x] ){
                  index=1;
                  break;
                }
              }
              if(index == -1){
                lista_sin_repetir[elementos_insertados] = lista[x];
                elementos_insertados++;
              }
          }//for
                // Mostramos el Arreglo sin numeros Repetidos
                System.out.println("\n Arreglo de Numeros no Repetidos: ");
                for (int k=0;k<elementos_insertados;k++){
                  System.out.print(" "+lista_sin_repetir[k]);

                }






                      }
                        });

            salir.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent ev){

                System.exit(0);

              }
            });




        }//Constructor



        public void initComponets(){
          eti = new JLabel("Cuantos Numeros Desea Generar: ");

          txt = new JTextField(30);
          salir = new JButton("Salir");
          generar = new JButton("Generar Numeros.");

          add(eti);
          add(txt);
          add(salir);
          add(generar);

          eti.setBounds(20,90,250,30);

          txt.setBounds(260,90,150,30);

          generar.setBounds(150,300,200,30);
          salir.setBounds(450,300,100,30);

        }



}//Ventana
