/*Importamos la clase Scanner el cual nos provee metodos
para poder leer valores de entrada de varios tipos de datos.
*/
import java.util.Scanner;

// Creamos la clase principal del programa.
public class Alumno{
  //Creamos la clase del metodo main.
  public static void main(String[] args){
    // Creamos nuestras variales, con el tipo de dato.
    String nombre;
    String apellidoPa;
    int edad;
    float promedio;
    String nivelEd;
    // Creamos un Objeto de tipo Scanner para leer los valores de entrada
    Scanner lee = new Scanner(System.in);

    //Capturamos los Datos del Alumno.
    System.out.println("\n Datos del Alumno.");

    System.out.println("\n Ingresa el Nombre: ");
    nombre = lee.nextLine();
    System.out.println("\n Ingresa el Apellido Paterno: ");
    apellidoPa = lee.nextLine();
    System.out.println("\n Ingresa su Edad: ");
    edad = lee.nextInt();
    System.out.println("\n Ingresa su Promedio: ");
    promedio = lee.nextFloat();
    System.out.println("\n Ingresa su Nivel de Estudios: ");
    nivelEd = lee.nextLine();
    nivelEd = lee.nextLine();

    //Imprimimos los Datos del Alumno.
    System.out.println("\n Imprimiendo Datos: ");
    System.out.println("\n "+nombre);
    System.out.println("\n "+apellidoPa);
    System.out.println("\n "+edad);
    System.out.println("\n "+promedio);
    System.out.println("\n "+nivelEd);


  }//main

}//Alumno
