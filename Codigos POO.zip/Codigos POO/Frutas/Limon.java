//Paquete
package Frutas;
//Clase Limon que Hereda de la Clase Citricos.
public class Limon extends Citricos{
  //Atributos
  private String vitaminas;
  private String minerales;
  private float calorias;

  //Metodos dela Clase Limon.
  public void rayar(){
    System.out.println("\nRayando el limon");
  }

  public void exprimir(){
    System.out.println("\nExprimiendo el limon");
  }

  public void hacerAgua(){
    System.out.println("\nHaciendo agua de limon");
  }

}
