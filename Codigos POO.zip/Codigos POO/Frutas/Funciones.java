//Paquete
package Frutas;
//Scanner y ArrayList
import java.util.Scanner;
import java.util.ArrayList;

//Clase Abstracta Funciones.
public abstract class Funciones{
  //Funcion que Agrega al Final.
  public static void agregaF(ArrayList<Frutas> arr){
    arr.add(new Secas(arr.size()));
  }
  //Funcion que Agrega al Inicio.
  public static void agregaI(ArrayList<Frutas> arr){
    arr.add(0, new Secas(arr.size()));
  }
  //Funcion que Agrega en Posicion X
  public static void agregaX(int c, ArrayList<Frutas> arr){
    arr.set(c, new Secas(arr.size()));
  }
  //Funcion que ELimina al Inico.
  public static void eliminarI(ArrayList<Frutas> arr){
    arr.remove(0);
  }
  //funcion que elimina al Final.
  public static void eliminarF(ArrayList<Frutas> arr){
    arr.remove(arr.size());
  }
  //Funcion que elimna por ID
  public static void eliminarID(Secas x, ArrayList<Frutas> arr){
    arr.remove(x);
  }
  //Funcion que consulta o imprime todo el ArrayList.
  public static void consulta(ArrayList<Frutas> arr){
    System.out.println(arr);
  }
  //Funcion que busca un elemento del ArrayList por ID.
  public static void busqueda(Secas x, ArrayList<Frutas> arr){
    int c;
    c = arr.indexOf(x);
    System.out.println(arr.get(c));
  }
}
