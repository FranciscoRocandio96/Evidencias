//Paquete
package Frutas;
//Clase Nuetras que Implementa la Interfaz Frutas.
public class Neutras implements Frutas{
  //Atributos
  private String antioxidantes;
  private float fibra;
  private String gradoMadurez;

  //Metodos de la clase Neutras
  public void vender(){
    System.out.println("\nVendiendo fruto neutro");
  }

  public void picar(){
    System.out.println("\nPicando fruto neutro");
  }

  public void mascarilla(){
    System.out.println("\nHaciendo mascarilla con el fruto neutro");
  }
  //Implementacion de los Metodos de la Interfaz Frutas.
  public void pesar(){
    System.out.println("\nPesando fruto neutro");
  }
  public void arrancar(){
    System.out.println("\nArrancando fruto neutro");
  }
  public void comprar(){
    System.out.println("\nComprando fruto neutro");
  }
  //Metodo para consultar el nombre de la Fruta
  public String getNombre(){
    return nombre;
  }

}
