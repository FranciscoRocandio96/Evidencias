//Paquete
package Frutas;
//Scanner y ArrayList.
import java.util.Scanner;
import java.util.ArrayList;

//Clase Principal que Hereda de la clase Abstracta Funciones.
public class Principal extends Funciones{
  //Metodo main.
  public static void main(String[] args) {
    //Variables a utilizar
    int c;
    int aux;
    int aux2;
    //Declararcion de un ArrayList de Tipo Frutas.
    ArrayList<Frutas> arr = new ArrayList<Frutas>();
    //MENU de Opciones.
    do {
      Scanner lee = new Scanner(System.in);
      System.out.println("1.- Agregar al Inicio");
      System.out.println("2.- Agregar al Final");
      System.out.println("3.- Agregar el Posicion X");
      System.out.println("4.- Eliminar al Inicio");
      System.out.println("5.- Eliminar al Final");
      System.out.println("6.- Eliminar por ID");
      System.out.println("7.- Consultar/Imprimir Todos");
      System.out.println("8.- Buscar por ID");
      System.out.println("9.- Salir");
      System.out.println("\nIngresa una Opcion: ");
      c = lee.nextInt();

      //Cada uno de los Case Correspondientes a las Opciones del MENU.
      switch(c){
        case 1:
          System.out.println("Se Agrego un Elemento al Inicio.\n");
          //Funcion Agrega al Inicio.
          agregaI(arr);
        break;
        case 2:
          System.out.println("Se Agrego un Elemento al Final.\n");
          //Funcion Agrega al Final.
          agregaF(arr);
        break;
        case 3:
        //Verificamos que el ArrayList no este vacio.
         if(arr.isEmpty() ){
            System.out.println("ArrayList Vacio Ingrese Datos. \n");
          }
          //Si no esta vacio agregamos en la Posicion Ingresada.
          if(!arr.isEmpty()){
          System.out.println("Dame la posicion");
          aux = lee.nextInt();
          //Verificamos si la Posicion Ingresada es Mayos al Tamaño del ArrayList.
          if(aux > arr.size() ){
            System.out.println("La posicion es Mayor al ArrayList Ingrese mas Datos.\n");
          }
          //Si la Posicion es menor al tamaño del ArrayList se agrega el Dato en la posicion ingresada.
          if(aux <= arr.size() ){
            System.out.println("Dato Agregado. \n");
                agregaX(aux, arr);
            }


        }//if
        break;
        case 4:
        //Verificamos si el ArrayList esta Vacio.
        if(arr.isEmpty()){
          System.out.println("ArrayList Vacio Ingrese Datos.\n");
        }else{
          //De lo contrario Eliminamos
          System.out.println("Dato Eliminado.\n");
          eliminarI(arr);
        }
        break;
        case 5:
        //Verificamos si el ArrayList esta Vacio.
        if(arr.isEmpty()){
          System.out.println("ArrayList Vacio Ingrese Datos.\n");
        }
        else{
          //De lo contrario Eliminamos
          System.out.println("Dato Eliminado.\n");
          eliminarF(arr);
        }

        break;
        case 6:
          //Pedimos el ID
          System.out.println("Dame el ID");
          aux = lee.nextInt();
          //Creamos una Variable de tipo Secas y pasamos el ID
          Secas x = new Secas(aux);
          //Eliminamos el Objeto con ese ID correspondiente en el ArrayList.
          eliminarID(x, arr);
        break;
        case 7:
          //Consultamos el ArrayList.
          consulta(arr);
        break;
        case 8:
          //Buscamos un Objeto con un ID en especifico
          System.out.println("Dame el ID");
          aux = lee.nextInt();
          Secas y = new Secas(aux);
          aux2 = arr.indexOf(y);
          if(aux2 != -1){
          busqueda(y, arr);
        }else{
          System.out.println("El Objeto no Existe.\n");
        }
        break;
        case 9:
        //Salir del Programa.
        System.out.println("Usted a Salido.\n");
        System.exit(0);
        break;
        default:
          //Cuando se Ingresa Una Opcion no Valida.
          System.out.println("Opcion no valida");
        break;
      }

    } while (c!=9);
  }

}
