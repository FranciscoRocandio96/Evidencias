//Paquete
package Frutas;
//Clase Naranja que Hereda de la clase Abstracta Citricos.
public class Naranja extends Citricos{

  //Atributos.
  private float tiempo;
  private String sabor;
  private float vitaminaC;

  //Metodos de la clase Naranja.
  public void hacerJugo(){
    System.out.println("\nHaciendo jugo de naranja");
  }

  public void sacarGajos(){
      System.out.println("\nSacando gajos de la naranja");
  }

  public void chilito(){
        System.out.println("\nHechando chilito a la naranja");
  }
}
