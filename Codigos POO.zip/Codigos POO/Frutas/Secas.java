//Paquete
package Frutas;
//Clase Secas que Implementa la Interfaz Frutas.
public class Secas implements Frutas{
  //Atributos
  private float tamano;
  private float peso;
  private String color;
  private int idProduc;

  //Metodo para obtener el Id de la Fruta.
  public Secas(int d){
    idProduc = d;
  }

  //Metodo para Consultar el Nombre de la Fruta
  public String getNombre(){
    return nombre;
  }

  //Metodos de la CLase Secas.
  public void hidratar(){
    System.out.println("\nHidratando el frut seco");
  }

  public void calcVitaminas(){
    System.out.println("\nCalculando vitaminas del fruto seco");
  }

  public void tostar(){
    System.out.println("\nTostando el fruto seco");
  }

  //Implementacion de los Metodos de la Interfaz Frutas
  public void pesar(){
    System.out.println("\nPesando fruto seco");
  }
  public void arrancar(){
    System.out.println("\nArrancando fruto seco");
  }
  public void comprar(){
    System.out.println("\nComprando fruto seco");
  }

  //Metodo to String.
  public String toString(){
    String cadena = "\n Tamano: "+ tamano;
    cadena += "\n ID: "+ idProduc;
    cadena += "\n Nombre: "+ getNombre();
    cadena += "\n Peso: "+ peso;
    cadena += "\n Color: "+ color + "\n";
    return cadena;
  }//toString


  //Metodo equals
  public boolean equals(Object ob){
    Secas x = (Secas) ob;
    if( x.idProduc == this.idProduc )
      return true;
    return false;
  }

}
