//Paquete
package Frutas;
//Clase Abstracta Citricos que Implementa la Interfaz Frutas.
public abstract class Citricos implements Frutas{
  //Atributos
  private int piezas;
  private String color;
  private float costo;

  //Metodos
  public void comer(){
    System.out.println("\nComiendo citrico");
  }

  //Metodos propios de la clase Citricos

  public void cortar(){
    System.out.println("\nCortando el citrico");
  }

  public void hacerZumo(){
    System.out.println("\nHaciendo Zumo del citrico");
  }

  //Implementamos los Metodos de la Interfaz Fruta
  public String getNombre(){
    return nombre;
  }

  public void pesar(){
    System.out.println("\nPesando citrico");
  }
  public void arrancar(){
    System.out.println("\nArrancando citrico");
  }
  public void comprar(){
    System.out.println("\nComprando citrico");
  }

}
