//Pauqte
package Frutas;
//Interfaz Frutas
public interface Frutas{
  //Atributos
  String nombre="";//<-------------------

  //Declararios de los Metodos abstractos
  public abstract void pesar();
  public abstract void arrancar();
  public abstract void comprar();
  public abstract String getNombre();//<------------------


}
