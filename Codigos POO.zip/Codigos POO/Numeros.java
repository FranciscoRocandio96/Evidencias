/*Importamos la clase Scanner el cual nos provee metodos
para poder leer valores de entrada de varios tipos de datos.
*/

import java.util.Scanner;
//Creamos la clase principal del programa.
public class Numeros{
	//Creamos la clase del metodo main.
public static void main(String[] args){
	//Creamos el objeto de tipo Scanner para la captura de datos.
	//Creamos las variables del tipo de dato a utilizar.
	Scanner lee = new Scanner(System.in);
	int n;
	int m;
	int x;
	//Capturamos los datos.
	System.out.println("\n Ingresa N: ");
	n = lee.nextInt();
	System.out.println("\n Ingresa M: ");
	m = lee.nextInt();
	System.out.println("\n Ingresa X: ");
	x = lee.nextInt();

	/*Evaluamos los datos para saber cual es el mayor y el menor,
	 para asi poder realizar la impresion de la serie.*/

	 // n es menor que m
	if(n < m){
		//bucle for para la impresion
	for(int i=n; i<=m; i=i+x){
		System.out.print(" "+i);
		}//for

	}//if

	// n es mayor que m
	if(n > m){
		//bucle for para la impresion
	for(int j=n; j>=m; j=j-x){
		System.out.print(" "+j);
			}//for

		}//if

	}//main

}//Numeros
