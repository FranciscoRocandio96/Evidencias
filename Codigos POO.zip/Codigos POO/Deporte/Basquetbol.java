package Deporte;

//Clase Basquetbol que implementa la Interfaz Deportes
public class Basquetbol implements Deportes{
	//Atributos
	private int numJugador;
	private String colorUniforme;

	//<<----------Constructores------->>
	public Basquetbol() {
		System.out.println("\n\t************************\n\t*  Jugando Basquetbol  *\n\t************************");
	}


	//<<----------Inician metodos concretos------->>
	public void cambios(){
		System.out.println("\n\tSe ha realizado un cambio");
	}

	public void faltas(){
		System.out.println("\n\tSe ha cometido una falta");
	}
	//<<-----Inician los metodos  heredados------>>

	public void datosEquipo(){
		System.out.println("\n\tLos datos del equipo son: .....");
		System.out.println("\n\tNombre:New Orleans");
	}

	//Metodos de la clase Basquetbol
	public void Competir(){
		System.out.println("\n\tEl equipo esta compitiendo Final");
	}
	public void Practicar(){
		System.out.println("\n\tEl equipo esta practicando Tiros de 3 puntos");
	}
	public void liga(){
		System.out.println("\n\tLa liga del equipo es: NBA ......");
	}

}//Basquetbol
