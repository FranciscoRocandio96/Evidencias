package Deporte;

   //Clase Principal
   public class Principal{
   //Metodo main
   public static void main(String[] args){
    //Creamos Los Objetos de las clases Correspondientes e invocamos los metodos.

    Basquetbol obj1=new Basquetbol();

    obj1.cambios();
		obj1.faltas();
		obj1.datosEquipo();
		obj1.Competir();
		obj1.Practicar();
		obj1.liga();

		Americano obj2=new Americano();

		obj2.Entrenamiento();
		obj2.jugada();
		obj2.datosEquipo();
		obj2.Competir();
		obj2.Practicar();
		obj2.liga();
  }//main
  
}//Principal
