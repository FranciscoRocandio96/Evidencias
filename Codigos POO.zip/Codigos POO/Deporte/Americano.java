package Deporte;
//Clase Americano que Hereda de Futbol.
public class Americano extends Futbol{
	//Atributos
	private String jugada;

	//<<-----Inician los metodos  heredados------>>
	public Americano() {
		System.out.println("\n\t\n\t********************************\n\t*   Jugando Futbol Americano   *\n\t********************************");
	}

	public void datosEquipo(){
		System.out.println("\n\tLos datos del equipo son: .....");
	}

	public void Competir(){
		System.out.println("\n\tEl equipo esta compitiendo Partido Amistoso (Pretemporada )");
	}

	//<<----------Inician metodos concretos------->>
	public void jugada(){
		System.out.println("\n\tLa jugada siguiente es: 1a y 10....");
	}




}//Americano
