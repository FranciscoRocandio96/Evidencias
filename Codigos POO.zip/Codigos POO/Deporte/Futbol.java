package Deporte;
//Clase Futbol que implementa de la Interfaz Deportes.
public abstract class Futbol implements Deportes{
	//Atributos
	private int numJug;
	private String tipoCampo, nomJugador;

	//<<----------Inician metodos concretos------->>
	public void Entrenamiento(){
	  System.out.println("\n\tEquipo entrenando");
	}

	//<<-----Inician los metodos  heredados------>>
	public void Practicar(){
		System.out.println("\n\tEl equipo esta practicando Gol de Campo");
	}
	public void liga(){
		System.out.println("\n\tLa liga del equipo es:NFL, MLS ,FMF ......");
	}


}//Deportes
