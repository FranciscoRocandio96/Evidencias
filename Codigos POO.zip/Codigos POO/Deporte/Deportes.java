package Deporte;
//Interfaz
public interface Deportes{
  //Atributos
  String lugar="";
  //Metodos abstractos
  public abstract void datosEquipo();
  public abstract void Competir();
  public abstract void Practicar();
  public abstract void liga();
}//Deportes
