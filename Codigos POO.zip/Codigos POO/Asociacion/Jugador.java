//Paquete
package Asociacion;
//Scanner
import java.util.Scanner;
//Clase Jugador
public class Jugador{

  //Atributos
  private String nombre;
  private String deporte;
  private String posicion;
  private int edad;
  private Uniforme a;//Asignacion -UJ

  //Metodo de Relacion entre Clases
  public void setUniforme( Uniforme t ){
    a = t; // Asignacion - Uniforme a Jugador
  }

  //Metodo para Pedir Datos
  public  void pedirDatos(){
    Scanner lee = new Scanner(System.in);
    System.out.println("\n Ingresa el Deporte: ");
    deporte = lee.nextLine();
    System.out.println("\n Ingresa Nombre: ");
    nombre = lee.nextLine();
    System.out.println("\n Ingresa Posicion: ");
    posicion = lee.nextLine();
    System.out.println("\n Ingresa la Edad: ");
    edad = lee.nextInt();

  }//pedirDatos

  //Metodo toString
  public String toString(){
    String cad = "\n Deporte: "+deporte;
    cad += "\n Nombre: "+nombre;
    cad += "\n Posicion: "+posicion;
    cad += "\n Edad: "+edad;
    //Concatenamos el metodo toString de la clase Asociada
    //por el metodo setUniforme().
    cad += a.toString();

    return cad;
  }

  //Metodos que imprimen un Mensaje 
  public void jugadorCorriendo(){
    System.out.println("\n Jugador Corriendo. ");
  }

  public void jugadorDescansando(){
      System.out.println("\n Jugador Descansando. ");
  }




}
