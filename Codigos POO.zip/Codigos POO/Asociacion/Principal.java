//Paquete
package Asociacion;
//Clase Principal
public class Principal{
  //Metodo main
  public static void main(String[] args){
    //Creamos un objeto de tipo Jugador
    Jugador j = new Jugador();
    //invocamos sus Metodos
    j.pedirDatos();
    j.jugadorCorriendo();
    j.jugadorDescansando();
    //Cramos un objeto de tipo Uniforme
    Uniforme u = new Uniforme();
    //invocamos sus Metodos
    u.pedirDatos();
    u.lavando();
    u.elaborando();

    //Enviamos un objeto de tipo uniforme al usar el metodo para la Asociacion.
    j.setUniforme( u );

    //Comprobamos la Asociacion imprimiendo el Objero Jugador.
    System.out.println( j );

  }


}
