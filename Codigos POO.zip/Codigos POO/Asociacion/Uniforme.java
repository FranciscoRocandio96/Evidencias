//Paquete
package Asociacion;
//Scanner
import java.util.Scanner;
//Clase Uniforme
public class Uniforme{
  //Atributos
  private String color;
  private String talla;
  private int numero;
  //Metodo para pedir Datos.
  public void pedirDatos(){
    Scanner lee = new Scanner(System.in);

    System.out.println("\nUniforme: \n \n Ingresa el Color: ");
    color = lee.nextLine();
    System.out.println("\n Ingresa la Talla: ");
    talla = lee.nextLine();
    System.out.println("\n Ingresa el Numero: ");
    numero = lee.nextInt();
  }

  //Metodo toString
  public String toString(){
    String cad = "\n Color: "+color;
    cad += "\n Talla: "+talla;
    cad += "\n Numero: "+numero;

    return cad;
  }

  //Metodos que imprimen un Mensaje
  public void lavando(){
    System.out.println("\n Uniforme en proceso de Lavado. ");
  }

  public void elaborando(){
      System.out.println("\n El uniforme se esta Elaborando . ");
  }


}// Uniforme
