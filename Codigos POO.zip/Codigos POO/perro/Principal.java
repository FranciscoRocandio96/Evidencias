//Primero colocamos el nombre del paquete donde se encuentran los codigos.
package perro;
//Importamos las clases necesarias
import java.util.Scanner;

  //Creamos la clase principal del codigo 2
  public class Principal{

    //Creamos la clase del metodo main
  public static void main(String[] args){

    //Creamos un objeto y utilizamos el construcor 1 del codigo 1

    Perro obj1 = new Perro();//Ivoca Constructor
    //asignamos valores
    obj1.setColor("Amarillo");
    obj1.setNombre("Morris");
    //imprimimos usando Getters
    System.out.println(obj1.getNombre());
    System.out.println(obj1.getColor());
    //Impimimos el Objeto
    System.out.println(obj1);

  }//main

}//Principal
