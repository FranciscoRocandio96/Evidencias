//Primero colocamos el nombre del paquete donde se encuentran los codigos.
package perro;
//importamos las clases necesarias
import java.util.Scanner;

//creamos la clase principal codigo 1
public class Perro{

  //Creamos los atributos necesarios.
  private String raza,nombre,color;
  private float peso;

  //Creamos el construcor 1
  public Perro(){
    //Este es el construtor x default por que no tiene parametros
    System.out.println("\n Construyendo Perro.");
    nombre ="Desconocido";
    raza = "Desconocido";
    color = "Sin Color";
    peso = 0;
  }
  //Creamos el Costructor 2 que recibe un tipo de dato
  public Perro(String n){
    this();//Objeto que invoca al Metodo
    nombre = n;
  }
  //Creamos el Constructor 3 que recibe 2 tipos de datos.
  public Perro(String n, float p){
    this();
    nombre = n;
    peso =p;
  }

  //Creamos los Setters
  public void setRaza(String r){
    raza = r;
  }

  public void setNombre(String n){
    nombre = n;
  }
  public void setColor(String r){
    color = r;
  }
  public void setPeso(float peso){
    this.peso = peso;
  }

  //Creamos los Getters
  public String getRaza(){
    return raza;
  }
  public String getNombre(){
    return nombre;
  }
  public String getColor(){
    return color;
  }
  public float getPeso(){
    return peso;
  }

    // Creamos el Metodo toString.
    public String toString(){
      String cad = "\n Perro: "+ getNombre();
      cad+="\nRaza: "+getRaza();
      cad+="\nColor: "+getColor();
      cad+="\nPeso: "+getPeso()+"\n";
      return cad;
    }//toString


  //Metodo 1
  public void ladrar(){
    System.out.println("\n Guaua...guau");
  }//ladrar

  //Metodo 2
  public void vacunar(){
    System.out.println("\n Vacunado");
  }//vacunar

  //Creamos el Metodo main.
  public static void main(String[] args){

    //Creamos 3 objetos para utilizar los 3 Constructores diferentes.
    Perro obj1 = new Perro();

    System.out.println(obj1 );

    Perro obj2 = new Perro("Morris!");

    System.out.println(obj2);

    Perro obj3 = new Perro("Grande",95.58f);
    System.out.println(obj3);

  }//main


}//Perro
