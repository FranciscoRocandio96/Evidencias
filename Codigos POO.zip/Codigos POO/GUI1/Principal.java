//Paquete
package GUI1;
//Clase que contiene los Eventos y Componentes
import javax.swing.*;
import javax.swing.*;
//Clase Principal
public class Principal{
    //metodo main
    public static void main( String [] args ){
    //Creamos 3 Ventanas
    Ventana1 v = new Ventana1();
    Ventana1 x = new Ventana1();
    Ventana1 z = new Ventana1();
    //Creamos un arreglo de 50 Ventanas
    Ventana1[] arr = new Ventana1[50];
    for( int i = 0; i < 50 ; i++){
        arr[i] = new Ventana1();
    }

  }//main



}//Principal
