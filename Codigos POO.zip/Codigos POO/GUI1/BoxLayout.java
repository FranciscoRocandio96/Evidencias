//Paquete
package GUI1;
//Clase que contiene los Eventos y Componentes
import javax.swing.*;
//Clase BoxLayout
public class BoxLayout{

    //Main
    public static void main( String [] args ){
        //Creamos una Ventana un JFrame
        JFrame vent = new JFrame("VENTANA1");
        //Creamos sus Tamaño (x,y)
        vent.setSize(300,400);
        //Hacemos visible la Ventana
        vent.setVisible(true);
        //No podemos Modificar su tamaño
        vent.setResizable(false);
        //Creamos la Instruccion que cierra la Ventana pero no termina la ejecucion del programa
		    vent.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

    }//Main


}//Clase
