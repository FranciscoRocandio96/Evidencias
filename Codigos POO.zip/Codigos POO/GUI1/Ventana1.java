//Paquete
package GUI1;
//Clase que contiene los Eventos y Componentes
import javax.swing.*;
import java.awt.*;
//La Clase Ventana que Hereda de JFrame
public class Ventana1 extends JFrame{
    //Creamos un Panel
    JPanel panel;
    //Creamos el Constructor
    public Ventana1(){
        //Damos tamaño
        this.setSize(400,350);
        //Queno se pueda modificar su tamaño
        this.setResizable(false);
        //Invocamos al metodo initComponents
        this.initComponents();
        //Funcion que cierra la Ventana
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Hacemos Visible la Ventana
        this.setVisible(true);

    }//Constructor

    //metodo initComponents
    public void initComponents(){
        //Componentes
        panel = new JPanel();
        //Cambiamos el color de la Ventana
        panel.setBackground(Color.MAGENTA);
        add(panel);//Agrega el Panel al Frame
    }//initComponents



}//Clase
