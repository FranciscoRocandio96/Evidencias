//Paquete
package GUI2;
// Componenetes y Eventos
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
//Clase Ventana que hereda de JFrame
public class Ventana extends JFrame{

  //Atributos y Componenetes
  JButton btn1,btn2,btn3,btn4; // botones
  JRadioButton rbt1,rbt2,rbt3,rbt4,rbt5;//Grupo de botones
  JTextField txt1,txt2; // caja de Texto
  JLabel et1,et2;//Etiquetas

  //Constructor
  public Ventana(){
    //Titulo
    setTitle("Practica");
    //Tamaño
    setSize(500,500);
    //Cambiamos el Color
    getContentPane().setBackground(Color.GREEN);
    //Notrosos colocaremos nuestros componetes a donde queramos
    setLayout(null);
    //Operacion para cerrar la Ventana
    setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    //Invocando al metodo
    initComponets();

    // CLASE ANONIMA del evento para el Boton Salir
    btn2.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //Cerramos la Ventana
        System.out.println("Usted a Salido..");
        System.exit(0);
      }
    });
    //CLASE ANONIMA para el boton Color
    btn1.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //Verificamos que boton esta sellecionado y siguiente cambiamos el color de la Ventana
        if(rbt1.isSelected()==true){getContentPane().setBackground(Color.PINK);}
        if(rbt2.isSelected()==true){getContentPane().setBackground(Color.BLUE);}
        if(rbt3.isSelected()==true){getContentPane().setBackground(Color.YELLOW);}
        if(rbt4.isSelected()==true){getContentPane().setBackground(Color.BLACK);}
        if(rbt5.isSelected()==true){getContentPane().setBackground(Color.MAGENTA);}
      }
    });

    //CLASE ANONIMA para Cambiar el nombre de la Ventana
    txt1.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        String cad;
        //Obtenemos lo que esta en JTextField
        cad = txt1.getText();
        //Cambiamos el Titulo de la Ventana por lo que se obtuvo del JTextField
        setTitle(cad);
        //Colocamos Vacio en el JTextField
        txt1.setText("");
      }
    });
    //CLASE ANONIMA para Mostrar un Msj mas lo escrito en el JTextField
    btn3.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        String cad;
        //Obtenemos el texto del JTextField
        cad = txt2.getText();
        //Enviamos un MSJ en pantalla mas lo que se obtiene de JTextField
        JOptionPane.showMessageDialog(null,"Que Tengas Un Lindo Dia "+cad);
        //Colocamos vacio
        txt2.setText("");
      }
    });
    //CLASE ANONIMA Envia un msj con algun mensaje no ofensivo
    btn4.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //Enviamos un mensaje en pantalla sin palabras ofensivas
        JOptionPane.showMessageDialog(null,"Eres un Programador Baby de 4to Nivel..");
      }
    });


    // Hacemos Visible la Ventana
    setVisible(true);


  }// Ventana

    //Metodo initComponets
    /*En este metodo vamos a crear o inizializar
    los componentes, podemos colocar un nombre,
    o dar un tamaño especifico a ciertos componetes.
    */
    public void initComponets(){
    btn1 = new JButton("Color");
    btn2 = new JButton("Salir");
    btn3 = new JButton("Mensaje 1");
    btn4 = new JButton("Mensaje 2");
    txt1 = new JTextField(30);
    txt2 = new JTextField(30);
    et1 = new JLabel("Titulo");
    et2 = new JLabel("Nombre");

    rbt1 = new JRadioButton("Rosa");
    rbt2 = new JRadioButton("Azul");
    rbt3 = new JRadioButton("Amarillo");
    rbt4 = new JRadioButton("Negro");
    rbt5 = new JRadioButton("Magenta");

    //Grupo de Botones: para poder selecionar 1 y no marcar mas de 2
    ButtonGroup gb = new ButtonGroup();
    //Agregamos los botones al grupo de botones
    gb.add(rbt1);
    gb.add(rbt2);
    gb.add(rbt3);
    gb.add(rbt4);
    gb.add(rbt5);
    //Ahora agregamos todos lo componenets al Panel o JFrame
    add(btn1);
    add(btn2);
    add(btn3);
    add(btn4);

    add(rbt1);
    add(rbt2);
    add(rbt3);
    add(rbt4);
    add(rbt5);

    add(txt1);
    add(txt2);

    add(et1);
    add(et2);


        // Damos coordenadas de ubicacion del componete(x,y) y tamaño del mismo(x,y)
        rbt1.setBounds(50,50,90,30);
        rbt2.setBounds(50,85,90,30);
        rbt3.setBounds(50,120,90,30);
        rbt4.setBounds(50,155,90,30);
        rbt5.setBounds(50,190,90,30);

        btn1.setBounds(50,245,70,30);
        btn2.setBounds(50,300,70,30);

        et1.setBounds(190,50,120,30);
        et2.setBounds(190,100,120,30);

        txt1.setBounds(250,50,120,30);
        txt2.setBounds(250,100,120,30);

        btn3.setBounds(250,260,120,30);
        btn4.setBounds(250,300,120,30);



  }//initComponets





}//Ventana
