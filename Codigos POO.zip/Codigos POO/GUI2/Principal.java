//Paquete
package GUI2;
//Clase Principal
public class Principal{
  //Metodo main
  public static void main(String[] args){
    //Creamos un objeto de Ventana
    Ventana v1 = new Ventana();
  }

}
