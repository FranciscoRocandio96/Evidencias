/*Importamos la clase Scanner el cual nos provee metodos
para poder leer valores de entrada de varios tipos de datos.
*/
import java.util.Scanner;

//Creamos la clase principal del programa.
public class Frase{
  //Creamos la clase del metodo main.
  public static void main(String[] args){
    //Creamos las variables del tipo de dato a utilizar
    String frase;
    int num;
    //Creamos un objeto de tipo Scanner para la lectura de datos.
    Scanner lee = new Scanner(System.in);
    //Procedemos a pedir los datos.
    System.out.println("\n Ingresa una Frase: ");
    frase = lee.nextLine();
    System.out.println("\n Ingresa N: ");
    num = lee.nextInt();

    //Usamos un bucle for para la impresion.

    /*for(inicializacion; condicion; incremento o decremento){

    Sentencias a ejecutar
  }*/
    for(int x = 0; x < num; x++){
        System.out.println("\n "+frase);
    }//for

  }//main

}//Frase
