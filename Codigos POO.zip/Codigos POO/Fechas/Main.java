package Fechas;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;


public class Main{

    public static void main(String[] args){
        // lista donde se guardaran todas las fechas
        List<Fecha> lista = new ArrayList<Fecha>();
        Scanner a = new Scanner(System.in);
        String aux;

        System.out.println("\n Ingresa Fechas en Formato DD-MM-AAAA");
        System.out.println("\n Ingresa no \n Cuando ya no Quieras Ingresar Fechas");

        // ingresamos todas las fechas que el usuario desee
        do{
            System.out.println("\n Ingresa una Fecha: ");
            aux=a.next();
            if(!aux.equals("no")){
                lista.add(new Fecha(aux));
            }
        }while(!aux.equals("no"));

        // ordenamos la lista de fechas
        Collections.sort(lista);

        // imprimimos la lista de fechas
        System.out.println("\n Fechas Ordenadas !");
        for(int x=0; x<lista.size(); x++){
            System.out.println(lista.get(x));
        }

    }
}
