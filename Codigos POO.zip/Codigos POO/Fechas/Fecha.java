package Fechas;

// clase fecha que implementa la interface comparable
// se sobreeescribe el metodo compareTo() para con el metodo Collections.sort() le pasemos la lista y lo ordene solito

public class Fecha implements Comparable{

    // atributos que representan el dia, mes y año de una fecha
    private int dia;
    private int mes;
    private int anio;

    public Fecha(String a){
        setFecha(a);
    }

    // ingresamos una fecha con el formato dd-mm-aaaa con guines y sin espacios
    // despues separamos toda esa cadena en un arreglo de 3 elementos siendo uno el dia mes y año
    // convertimos cada elemento a entero y se lo pasamos a los atributos
    public void setFecha(String a){
        String[] array = a.split("-");
        dia=Integer.parseInt(array[0]);
        mes=Integer.parseInt(array[1]);
        anio=Integer.parseInt(array[2]);
    }

    // getters de los atributos dia, mes  y año
    public int getDia(){
        return dia;
    }
    public int getMes(){
        return mes;
    }
    public int getAnio(){
        return anio;
    }

    // metodo toString para darle formato a la hora de imprimir una fecha
    public String toString(){
        String cad="";
        cad=anio+"-"+mes+"-"+dia;
        return cad;
    }

    // el metodo compareTo pertenece a la interface Collections
    // regresa 1 si la fecha actual es mayor a la que se le pasa por parametro
    // regresa 0 si la fecha actual es igual a la que se le pasa por parametro
    // regresa -1 si la fecha actual es menor a la que se le pasa por parametro

    public int compareTo(Object o) {
       Fecha ref = (Fecha)o;
       int resp;
       if(this.getAnio()>ref.getAnio()){
           resp=1;
       }else if(this.getAnio()<ref.getAnio()){
           resp=-1;
       }else{
           if(this.getMes()>ref.getMes()){
               resp=1;
           }else if(this.getMes()<ref.getMes()){
               resp=-1;
           }else{
               if(this.getDia()>ref.getDia()){
                   resp=1;
               }else if(this.getDia()<ref.getDia()){
                   resp=-1;
               }else{
                   resp=0;
               }
           }
       }
       return resp;

   }
}
