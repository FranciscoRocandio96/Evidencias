//Paquete donde estan todos los codigos
package Figuras;
import java.util.Scanner;
//Clase Circulo que Hereda de la clase Figura
public class Circulo extends Figura{

	//Constructor
	  public Circulo(){

		System.out.println("\n Circulo ");

	}
		//Metodo para calcular el Area.
	  public void CalcArea(){

		Scanner x = new Scanner(System.in);

		System.out.print("\n Ingresa el valor del radio: ");
		setLado( x.nextFloat() );
		setArea((3.1416f) * (getLado()*getLado()));

	}

	//Metodo para calcular el Perimetro.
	public void CalcPerim(){
		setPerim((3.1416f) * (getLado()*2));

	}



}//Circulo
