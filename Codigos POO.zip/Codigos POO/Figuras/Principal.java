//Paquete donde estan todos los codigos
package Figuras;
//Clase Principal del Programa.
public class Principal{
    //Main
    public static void main ( String [] args){
		//Cuadrado
		Cuadrado obj= new Cuadrado();
    //Calculamos Area y Perimetro
		obj.CalcArea();
		obj.CalcPerim();
    //Mostramos los resultados.
		System.out.println("\n El Area del Cuadrado es: "+obj.getArea()+" cm");
		System.out.println("\n El Perimetro del Cuadrado es: "+obj.getPerim()+" cm");

		//Triangulo
		Triangulo obj1= new Triangulo();
    //Calculamos Area y Perimetro
		obj1.CalcArea();
		obj1.CalcPerim();
    //Mostramos los resultados.
		System.out.println("\n El Area del Triangulo es: "+obj1.getArea()+" cm");
		System.out.println("\n El Perimetro del Triangulo es: "+obj1.getPerim()+" cm");

		//Circulo
		Circulo obj2= new Circulo();
    //Calculamos Area y Perimetro
		obj2.CalcArea();
    obj2.CalcPerim();
    //Mostramos los resultados.
    System.out.println("\n El Area del Circulo es: "+obj2.getArea()+" cm");
		System.out.println("\n El Perimetro del Circulo es: "+obj2.getPerim()+" cm");

		//Regular
		Regular obj3= new Regular();
    //Calculamos Area y Perimetro
		obj3.CalcArea();
		obj3.CalcPerim();
    //Mostramos los resultados.
    System.out.println("\n El Area del Regular es: "+obj3.getArea()+" cm");
		System.out.println("\n El Perimetro del Regular es: "+obj3.getPerim()+" cm");



	}//main

}//Principal
