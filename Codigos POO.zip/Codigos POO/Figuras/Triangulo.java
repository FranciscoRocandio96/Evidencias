//Paquete donde estan todos los codigos
package Figuras;
import java.util.Scanner;

//Clase Triangulo que Hereda de la clase Figura.
public class Triangulo extends Figura{

	//Atributos
	private float base;
	//Constructor
	public Triangulo(){

		System.out.println("\n Triangulo ");

	}
	//Metodo para calcular el Area.
	public void CalcArea(){
		//super();
		Scanner x = new Scanner(System.in);

		System.out.print("\n Ingresa el valor de la base: ");
		base = x.nextFloat();
		System.out.print("\n Ingresa el valor de la altura: ");
		setLado( x.nextFloat() );

		setArea( (base * getLado()) /2 );

	}

	//Metodo para calcular el Perimetro
	public void CalcPerim(){

		setPerim( base + (getLado()*2) );

	}


}//Triangulo
