package Figuras;
import java.util.Scanner;

public class Cuadrado extends Figura{

	public Cuadrado(){
		//super();
		System.out.println("\n Cuadrado ");
	}
	public void CalcArea(){
		Scanner x=new Scanner(System.in);
		System.out.print("\n Ingresa el Valor del Lado: ");
		setLado(x.nextFloat());
		setArea(getLado()*(getLado()));

	}
	public void CalcPerim(){
		setLado(10f);
		setPerim(getLado()*4);
	}



}
