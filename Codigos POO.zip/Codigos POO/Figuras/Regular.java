package Figuras;
import java.util.Scanner;
//Clase Regular que Hereda de la clase Figura
public class Regular extends Figura{
	//Atributos
	private float numLados, apotema;
	//Constructor
	public Regular(){

		System.out.println("\n Regular ");
	}
	//Metodo para calcular Area.
	public void CalcArea(){
		//super();
		Scanner x=new Scanner(System.in);

		System.out.print("\n Ingresa el valor del lado: ");
		setLado(x.nextFloat());
		System.out.print("\n Ingresa el No. de lados: ");
		numLados=x.nextFloat();
		System.out.print("\n Ingresa el valor del apotema: ");
		apotema=x.nextFloat();

		setArea((numLados * (getLado()) * apotema)/2);


	}

	//Metodo para calcular Perimetro
	public void CalcPerim(){
		setPerim(numLados * (getLado()));

	}



}//Regular
