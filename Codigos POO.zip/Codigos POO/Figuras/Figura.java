//Paquete donde estan todos los codigos
package Figuras;
import java.util.Scanner;

//clase Padre clase Figura
public class Figura{
	//Atributos
	private float area, perimetro, lado;

	//Constructor
	public Figura(){
		System.out.println("\n FIGURA ");
	}

	// Setters y Getters
	public void setArea(float a){
        area=a;
    }
    public void setPerim(float p ){
        perimetro=p;
    }
    public void setLado(float l){
        lado=l;
    }


		public float getArea(){
		return area;
		}
		public float getPerim(){
		return perimetro;
		}
		public float getLado(){
		return lado;
		}

		//toString
		public String toString(){

				String cad= "\nArea: "+ getArea();
        cad+= "\nPerimetro: "+ getPerim();
        cad+= "\nLado: "+ getLado();
        return cad;
	}

	//Metodo Calcular Area
	public void CalcArea(){
		System.out.println("\n Calcula Area");

	}

	//Metodo Calcular Perimetro
	public void CalcPerim(){
		 System.out.println("\n Calcula Perimetro");

	}


}
