package Colores;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.awt.*;

    //La Clase Ventana que Hereda de JFrame
public class Ventana extends JFrame{

      private JLabel eti,eti2;
      private JTextField txt;
      private JRadioButton rbtn,rbtn2,rbtn3,rbtn4;
      private ButtonGroup grupo;
      private JButton salir,color,agregar;
      private JTextArea area;



        //Creamos el Constructor
        public Ventana(){


            this.setTitle("Colores");
            this.setBounds(100,100,600,400);
            this.setLayout(null);
            initComponets();
            this.setResizable(false);
            this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);


            color.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent ev){

                if( rbtn.isSelected() == true ){
                    getContentPane().setBackground(Color.RED);
                }

                if( rbtn2.isSelected() == true ){
                    getContentPane().setBackground(Color.GREEN);
                }

                if( rbtn3.isSelected() == true ){
                    getContentPane().setBackground(Color.BLUE);
                }

                if( rbtn4.isSelected() == true ){
                    getContentPane().setBackground(Color.PINK);
                }



              }
            });



            agregar.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ev){
                  String cad = txt.getText();
                  area.append("\n"+cad);
                  txt.setText("");

                          }
                        });

            salir.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent ev){

                System.exit(0);

              }
            });




        }//Constructor






        public void initComponets(){
          eti = new JLabel("Ingresa un Texto: ");
          eti2 = new JLabel("Selecciona un Color: ");
          txt = new JTextField(30);
          rbtn = new JRadioButton("Rojo");
          rbtn2 = new JRadioButton("Verde");
          rbtn3 = new JRadioButton("Azul");
          rbtn4 = new JRadioButton("Rosa");
          salir = new JButton("Salir");
          color = new JButton("Cambiar Color");
          agregar = new JButton("Agregar Texto");
          area = new JTextArea();


          grupo = new ButtonGroup();
          grupo.add(rbtn);
          grupo.add(rbtn2);
          grupo.add(rbtn3);
          grupo.add(rbtn4);



          add(eti);
          add(eti2);
          add(txt);
          add(rbtn);
          add(rbtn2);
          add(rbtn3);
          add(rbtn4);
          add(salir);
          add(color);
          add(agregar);
          add(area);

          eti2.setBounds(20,80,130,30);
          eti.setBounds(200,50,130,30);
          txt.setBounds(200,90,150,30);

          rbtn.setBounds(50,130,100,30);
          rbtn2.setBounds(50,160,100,30);
          rbtn3.setBounds(50,190,100,30);
          rbtn4.setBounds(50,220,100,30);

          area.setBounds(380,50,200,200);


          color.setBounds(50,300,150,30);
          agregar.setBounds(250,300,150,30);
          salir.setBounds(450,300,100,30);

        }



}//Ventana
