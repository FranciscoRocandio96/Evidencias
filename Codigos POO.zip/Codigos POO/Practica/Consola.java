package Practica;
import java.util.Scanner;

public class Consola{

    private String marca;
    private String tipo;

    //Variable de Asociacion
    private Xbox x;
    //Variable de Composicion
    private Controles c;

    public void setXbox(Xbox a){
      x=a;
    }

    public Consola(){
      c = new Controles();
    }

    Scanner lee = new Scanner(System.in);

    public void pedirDatos(){
    System.out.println("\n Datos de la Consola.");
    System.out.println("\n Ingresa la Marca: ");
    marca=lee.nextLine();
    System.out.println("\n Ingresa tipo de Consola: ");
    tipo=lee.nextLine();

    c.pedirDatos();
    }

  public String toString(){
    String cad = "\n Datos de Consola. \n";
    cad+="\n Marca: "+marca;
    cad+="\n Tipo: "+tipo;
    cad+="\n"+x.toString();
    cad+="\n"+c.toString();
    return cad;
  }

  public void Comprar(){
    System.out.println("\n Comprando Consola !!");
  }

  public void Encender(){
    System.out.println("\n Encendiendo Consola !!");
  }

  public void Apagar(){
    System.out.println("\n Apagando Consola !!");
  }

}//consola
