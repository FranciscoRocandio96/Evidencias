package Practica;
import java.util.Scanner;

public class Tarjeta{
//Atributos
  private String marca;
  private int tam_memoria;
  private float gpu;
  private String made_in;

  Scanner lee = new Scanner(System.in);
  public void pedirDatos(){
    System.out.println("\n Datos de Tarjeta de Video ");
    System.out.println("\n Ingresa la Marca: ");
    marca=lee.nextLine();
    System.out.println("\n Ingresa Tamaño de la Memoria: ");
    tam_memoria=lee.nextInt();
    System.out.println("\n Ingresa GPU: ");
    gpu=lee.nextFloat();
    System.out.println("\n Ingresa donde se Fabrico: ");
    made_in=lee.nextLine();
    made_in=lee.nextLine();
  }

  public String toString(){
    String cad = "\n Datos Tarjeta de Video. \n";
    cad+="\n Marca: "+marca;
    cad+="\n Tamaño: "+tam_memoria;
    cad+="\n GPU: "+gpu;
    cad+="\n Made In: "+made_in;
    return cad;
  }
//Metodos
  public void Cambiar(){
    System.out.println("\n Cambiando Tarjeta Grafica del Xbox !!");
  }


    public void Configurar(){
      System.out.println("\n Configurando Tarjeta Grafica del Xbox !!");
    }

}//Tarjeta
