package Practica;
import java.util.Scanner;

public class Controles{

  private String color;
  private float precio;
  private String tipo;
  private float peso;

  Scanner lee = new Scanner(System.in);
  public void pedirDatos(){
    System.out.println("\n Datos de Controles ");
    System.out.println("\n Ingresa el Color: ");
    color=lee.nextLine();
    System.out.println("\n Ingresa el Precio: ");
    precio=lee.nextFloat();
    System.out.println("\n Ingresa Tipo de Control: ");
    tipo=lee.nextLine();
    tipo=lee.nextLine();
    System.out.println("\n Ingresa el Peso: ");
    peso=lee.nextFloat();

  }

  public String toString(){
    String cad = "\n Datos Tarjeta del Control. \n";
    cad+="\n Color: "+color;
    cad+="\n Precio: "+precio;
    cad+="\n Tipo: "+tipo;
    cad+="\n Peso: "+peso;
    return cad;
  }

  public void Conectar(){
    System.out.println("\n Conectando Control !!");
  }


    public void Cambiar(){
      System.out.println("\n Cambiando Control !!");
    }

}//controles
