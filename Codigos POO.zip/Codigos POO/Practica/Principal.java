package Practica;

public class Principal{

  public static void main(String[] args){

//Obejto de Xbox
    Xbox obj = new Xbox();
    obj.pedirDatos();
    System.out.println(obj);
    System.out.println("\n");
    obj.Encender();
    obj.Apagar();


//Metodos de Tarjeta
   Tarjeta obj2 = new Tarjeta();

   obj2.Cambiar();
   obj2.Configurar();


Consola obj3 = new Consola();
obj3.pedirDatos();
obj3.setXbox(obj);
System.out.println(obj3);

obj3.Comprar();
obj3.Encender();
obj3.Apagar();


Controles obj4 = new Controles();
obj4.Conectar();
obj4.Cambiar();
}//main


}//Principal
