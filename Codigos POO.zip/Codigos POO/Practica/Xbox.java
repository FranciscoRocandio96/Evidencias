package Practica;
import java.util.Scanner;


public class Xbox{

//Atributos
  private String color;
  private float peso;
  private float precio;

  //Variable de Composicion
  private Tarjeta t;
//Variable de Asociacion
  public Xbox(){
    t = new Tarjeta();
  }

  Scanner lee = new Scanner(System.in);
  public void pedirDatos(){
    System.out.println("\n Datos de Xbox ");
    System.out.println("\n Ingresa el Color: ");
    color=lee.nextLine();
    System.out.println("\n Ingresa el Peso: ");
    peso=lee.nextFloat();
    System.out.println("\n Ingresa el Precio: ");
    precio=lee.nextFloat();
    //Pidiendo los Datos de Tarjeta
    t.pedirDatos();
  }

  public String toString(){
    String cad = "\n Datos Xbox. \n";
    cad+="\n Color: "+color;
    cad+="\n Peso: "+peso;
    cad+="\n precio: $ "+precio;
    cad+="\n";
    //Agregando los datos de Tarjeta
    cad+= t.toString();
    return cad;
  }


//Metodos de Tarjeta
  public void Encender(){
    System.out.println("\n Encendiendo Xbox !! ");
  }

  public void Apagar(){
    System.out.println("\n Apagando Xbox !! ");

  }

}//clase xbox
