//Esta es la clase Principal del Programa
public class Hola_Mundo{

  // Aqui se encuenta la Clase del Metodo main
  public static void main(String[] args){

    //Instruccion de impresion en consola
    System.out.println("\n Hola Mundo. \n");
  }//Main

}//Hola_Mundo
