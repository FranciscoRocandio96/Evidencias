//Importamos las clases necesarias para el programa.
import java.util.Scanner;
//Creamos la Clase Principal.
public class Datos
{
	//Creamos todos los Atributos necesarios.
	private String nombre, apPaterno, apMaterno, direccion;
	private int edad;
	// Creamos el Metodo para pedir Datos.
	public  void setDatos(){
		Scanner dato= new Scanner(System.in);

		System.out.print("\nIngresa el Nombre: ");
		nombre=dato.nextLine();
		System.out.print("\nIngresa el Ap. Paterno: ");
		apPaterno=dato.nextLine();
		System.out.print("\nIngresa el Ap. Materno: ");
		apMaterno=dato.nextLine();
		System.out.print("\nIngresa la Edad: ");
		Scanner dato1= new Scanner(System.in);
		edad=dato1.nextInt();
		System.out.print("\nIngresa la Direccion: ");
		direccion=dato.nextLine();
	}//setDatos

	//Utilizamos el metodo toString()
	public String toString(){
		String datos= new String();
		datos="\nNombre: "+nombre+"\nAp.Paterno: "+apPaterno+"\nAp.Materno: "+apMaterno+"\nEdad: "+edad+"\nDireccion: "+direccion;
		System.out.println("\n "+datos);
		return datos;
	}//toString

	//Creamos una funcion para modificar los Datos, uando un switch.
	public void modificaDatos(int opc){
	Scanner dato1= new Scanner(System.in);
	switch(opc){

		case 1:
			System.out.print("\nIngresa el Nombre: ");
			nombre=dato1.nextLine();
		break;

		case 2:
			System.out.print("\nIngresa el Ap. Paterno: ");
			apPaterno=dato1.nextLine();
		break;

		case 3:
			System.out.print("\nIngresa el Ap. Materno: ");
			apMaterno=dato1.nextLine();
		break;

		case 4:
			System.out.print("\nIngresa la Edad: ");
			edad=dato1.nextInt();
		break;

		case 5:
			System.out.print("\nIngresa la Direccion: ");
			direccion=dato1.nextLine();
		break;
		case 6:
			System.exit(0);
		break;
			default:
			System.out.print("\nOpcion no valida ");

		}//sw

	}//modificaDatos

	//Creamos la clase del metodo main.
	public static void main(String[] args){

		//Creamos el Objeto
		Datos x = new Datos();
		int op, opc;
		//Creamos un switch on las opciones del programa.
		do{
		System.out.println("\n MENU de Datos.");
		System.out.print("\n1.Insertar Datos.\n2.Modificar Datos\n3.Consultar Datos\n4.Salir\n");
		System.out.print("\nElige una opcion: ");
		Scanner dato= new Scanner(System.in);
		op=dato.nextInt();

			switch(op){
				case 1:
					x.setDatos();
				break;
				case 2:

					System.out.print("\n1.Nombre\n2.apPaterno\n3.apMaterno\n4.Edad\n5.Direccion ");
					System.out.print("\nQue deseas Modificar: ");
					opc=dato.nextInt();
					x.modificaDatos(opc);
				break;

				case 3:
					x.toString();
				break;
				case 4:
					System.out.println("\nUsted a Salido");
					System.exit(0);
				break;

					default:
					System.out.print("\nOpcion no valida ");
			}//SW
		}while(op!=4);
	 }//Main

}//clase
