//PAquete
package GUI5;
	//Clase Principal
	public class Principal{
		//Metodo main
		public static void main(String[] args){
			//Creamos un objeto de Ventanas
			Ventanas v = new Ventanas();
			//hacemos visible la Ventana
			v.setVisible(true);

		}

	}
