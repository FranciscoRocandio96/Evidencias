//Paquete
package GUI5;
//Componentes para las Ventanas y Eventos
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;



  //Clase Ventanas que hereda de JFrame
  public class Ventanas extends JFrame{

    // Aqui Creamos La Venta Principal del Programa
    //*****************************************************************************************************************************
    //*****************************************************************************************************************************


    //Componentes y Atributos
    JCheckBox check1,check2,check3, check4, check5, check6, check7, check8, check9;
    JButton btn1, btn2, btn3, btnx1,btnx2;
    JTextField txt1;
    JLabel et1;
    ButtonGroup grupo;



    //Constructor de la clase
    public Ventanas(){
      //Tamaño
      setSize(600,500);
      //Color
      getContentPane().setBackground(Color.blue);
      //Null
      setLayout(null);
      //Titulo de la Ventana
      setTitle("Ventanas");
      //Invocacion del metodo que inicializa los Componentes
      initComponents();
      //Operacion que cierra la Ventana
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }//Constructor


    //Metodo que inicializa los Componentes
    public void initComponents(){
      //Creamos un objeto de el metodo Eventos
      Eventos e = new Eventos();

      //Botones de la Ventana Principal
      btn1=new JButton("Texto");
      btn2=new JButton("Imagen");
      btn3=new JButton("Dialogo");
      //Coodenadas y Tamaño
      btn1.setBounds(100, 200, 100, 40);
      btn2.setBounds(220, 200, 100, 40);
      btn3.setBounds(340, 200, 100, 40);

      //Agregamos el Evento
      btn1.addActionListener(e);
      btn2.addActionListener(e);
      btn3.addActionListener(e);

      //Agregamos los Botones a la ventana
      add(btn1);
      add(btn2);
      add(btn3);

    }//initComponents
//Aqui Termina La Creacion de la Ventana Principal del Programa
//*****************************************************************************************************************************
//*****************************************************************************************************************************

//#################################################################################################################################
//#################################################################################################################################
//Creamos la Ventana que se Genera al dar Clic al Boton Texto

    //Metodo para la ventana que genera Boton Texto
    public void VentanaPatron(){

      //Cramos una ventana
      JFrame ventana= new JFrame();
      //Tamaño
      ventana.setSize(400,500);
      //Color
      ventana.getContentPane().setBackground(Color.PINK);
      //Null
      ventana.setLayout(null);
      //Operacion que cierra la ventana
      ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      //Todos los checkbox con los nombres de los Paises
      check1=new JCheckBox("Mexico", false);
      check2=new JCheckBox("Paris", false);
      check3=new JCheckBox("Seoul", false);
      check4=new JCheckBox("Los Angeles", false);
      check5=new JCheckBox("Dubai", false);
      check6=new JCheckBox("Londres", false);
      check7=new JCheckBox("Rio de Janeiro", false);
      check8=new JCheckBox("Tokyo", false);
      check9=new JCheckBox("Kanto", false);
      //Boton OK
      btnx1 = new JButton("OK");

      //Coordenas y Tamaño
      check1.setBounds(30,10,150,30);
      check2.setBounds(30,50,150,30);
      check3.setBounds(30,90,150,30);
      check4.setBounds(30,130,150,30);
      check5.setBounds(30,170,150,30);
      check6.setBounds(30,210,150,30);
      check7.setBounds(30,250,150,30);
      check8.setBounds(30,290,150,30);
      check9.setBounds(30,330,150,30);

      //Color
      check1.setBackground(Color.pink);
      check2.setBackground(Color.pink);
      check3.setBackground(Color.pink);
      check4.setBackground(Color.pink);
      check5.setBackground(Color.pink);
      check6.setBackground(Color.pink);
      check7.setBackground(Color.pink);
      check8.setBackground(Color.pink);
      check9.setBackground(Color.pink);

      //Coordenas y tamaño Boton OK
      btnx1.setBounds(250,400,100,40);

      //Evento del Boton OK (CLASE ANONIMA)
      btnx1.addActionListener( new ActionListener(){
        //Verificamos las opciones que han sido seleccionadas
        String cad="Seleccionaste: \n";
        public void actionPerformed( ActionEvent ev1 ){
          if(check1.isSelected())
            cad=cad+"Mexico \n";
          if(check2.isSelected())
            cad=cad+"Paris \n";
          if(check3.isSelected())
            cad=cad+"Seoul \n";
          if(check4.isSelected())
            cad=cad+"Los Angeles \n";
          if(check5.isSelected())
            cad=cad+"Dubai \n";
          if(check6.isSelected())
            cad=cad+"Londres \n";
          if(check7.isSelected())
            cad=cad+"Rio de Janeiro \n";
          if(check8.isSelected())
            cad=cad+"Tokyo \n";
          if(check9.isSelected())
            cad=cad+"Kanto \n";
            //Contatenamos las Opciones que se han Seleccionado
            // y enviamos un Mensaje en pantalla con las opciones selecionadas
          JOptionPane.showMessageDialog(null,cad, "Mensaje", JOptionPane.INFORMATION_MESSAGE );
          cad="Seleccionaste: \n";
          //Despues Cerramos el Programa. Termina
          Salir();

        }
      });

      //Agregamos todos los checkbox y el boton a la ventana.
      ventana.add(check1);
      ventana.add(check2);
      ventana.add(check3);
      ventana.add(check4);
      ventana.add(check5);
      ventana.add(check6);
      ventana.add(check7);
      ventana.add(check8);
      ventana.add(check9);
      ventana.add(btnx1);
      ventana.setVisible(true);

    }//VentanaPatron


    //Metodo para Salir
    public void Salir(){
      System.exit(0);
    }
    //#################################################################################################################################
    //#################################################################################################################################
    //Aqui termina la Ventana que se Genera al dar Clic al Boton Texto


    //=================================================================================================================================
    //=================================================================================================================================
    //Aqui Inicia la Creacion del Lienzo y la Ventana al dar Clic en el boton Imagen

    //Creamos una Clase Lienzo que hereda de Ventana (PARA COLOCAR LAS IMAGENES)
    public class LienzoIm extends JFrame {

      //Constructor de la Clase
      public LienzoIm(){
        //Creamos un objeto de Canvas
        Canvas c = new DibujoCanvas();
        //Colocamos Color
        c.setBackground(Color.orange);
        //Agregamos al Centro
        add("Center", c);
        //Titulo
        setTitle("Imagenes");
        //Tamaño
        setSize(1000, 800);
        //Visible
        setVisible(true);
        //Operacion que oculta la Ventana
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

      }//Constructor

    }//LienzoIm


    //Clase DibujoCanvas que hereda de Canvas
    class DibujoCanvas extends Canvas{
      //Metodo paint
      public void paint(Graphics g){
          //Creamos los objetos de imagen ("Nombre_Paquete"/Nombre_Imagen).getImage();
          Image kang= new ImageIcon("GUI5/1.jpg").getImage();
          Image chul= new ImageIcon("GUI5/3.png").getImage();
          Image tres= new ImageIcon("GUI5/4.jpg").getImage();
          //Agregamos sus Coordenadas
          g.drawImage(chul, 700,100, this);
          g.drawImage(kang, 10,10, this);
          g.drawImage(tres, 700,400, this);

        }
    }//DibujoCanvas

    //=================================================================================================================================
    //=================================================================================================================================
    //Aqui Inicia la Creacion del Lienzo y la Ventana al dar Clic en el boton Imagen



    //---------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------
    //Aqui Inicia la creacion de las Ventanas que se generan al dar clic en el Boton Dialogo


    //Metodo para la ventana Dialogo
    public void Ventana3(){
      //creamos una ventana
      JFrame ventana= new JFrame();
      //Creamos sus Componenetes
      txt1 = new JTextField();
      et1 = new JLabel();
      btnx2 = new JButton("OK");
      //Tamaño
      ventana.setSize(600,270);
      //Color
      ventana.getContentPane().setBackground(Color.YELLOW);
      //null
      ventana.setLayout(null);

      //Coordenadas y tamaño
      et1.setText("Ingresa un numero del 1 al 10  ");
      et1.setBounds(210,50,260,30);
      txt1.setBounds(270,90,50,20);
      btnx2.setBounds(245,130,100,40);

      //Evento para el Boton OK
      btnx2.addActionListener(new ActionListener(){
      public void actionPerformed( ActionEvent ev ){
        //Obtenemos el contenido del JTextField
        String cad = txt1.getText();
        //Convertimos el String a int
        int n = Integer.parseInt(txt1.getText());
        if(n<=10){
          //Creamos el Numero de Ventanas Ingresado.
          Ventana[] obj = new Ventana[n];
          for(int i=0;i<obj.length;i++)
            obj[i] = new Ventana();
        }
        else
          //Es mayor a 10 Enviamos un Mensaje en pantalla
          JOptionPane.showMessageDialog(null,"El numero es mayor a 10","Mensaje" , JOptionPane.WARNING_MESSAGE );
      }
      });

      //Agregamos los Componetes a la Ventana
      ventana.add(txt1);
      ventana.add(et1);
      ventana.add(btnx2);
      ventana.setVisible(true);
    }

    //Creamos una Clase interna para crear las ventanas
    public class Ventana{
      //Constructor
      public Ventana(){
        //Nueva Ventana
      JFrame ventana1 = new JFrame();
      //Componetes
      JTextField txt2 = new JTextField(50);
      JLabel et2 = new JLabel();
      JButton btnx3 = new JButton("OK");
      JButton btnx4 = new JButton("Salir");
      //Tamaño
      ventana1.setSize(600,270);
      //Color
      ventana1.getContentPane().setBackground(Color.YELLOW);
      //null
      ventana1.setLayout(null);

      //Coordenadas y Tamaño
      et2.setText("HOLA ");
      et2.setBounds(280,50,260,30);
      btnx3.setBounds(200,150,80,40);
      btnx4.setBounds(330,150,80,40);

      //Evento del Boton OK
      btnx3.addActionListener(new ActionListener(){
        public void actionPerformed( ActionEvent ev ){
          //Crear 2 Ventanas mas
          Ventana1[] obj = new Ventana1[2];
          for(int i=0;i<obj.length;i++)
              obj[i] = new Ventana1();
      }});

      //Evento del Boton Salir
      btnx4.addActionListener(new ActionListener(){
        public void actionPerformed( ActionEvent ev ){
          //Crear 3 Ventanas mas
        Ventana1[] obj = new Ventana1[3];
        for(int i=0;i<obj.length;i++)
            obj[i] = new Ventana1();
      }});

      //Agregamos Elementos a la Ventana1
      ventana1.add(txt2);
      ventana1.add(et2);
      ventana1.add(btnx3);
      ventana1.add(btnx4);
      ventana1.setVisible(true);
      }
    }

    //Creamos clase Ventana1
    public class Ventana1{

      //Constructor
      public Ventana1(){
        //Nueva Ventana1
      JFrame ventana1 = new JFrame();
      //Componetes
      JTextField txt2 = new JTextField(50);
      JLabel et2 = new JLabel();
      JButton btnx3 = new JButton("OK");
      JButton btnx4 = new JButton("Salir");
      //Tamaño
      ventana1.setSize(600,270);
      //Color
      ventana1.getContentPane().setBackground(Color.YELLOW);
      //Null
      ventana1.setLayout(null);
      //ventana1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      //Coordenadas y Tamaño
      et2.setText("HOLA ");
      et2.setBounds(280,50,260,30);
      btnx3.setBounds(200,150,80,40);
      btnx4.setBounds(330,150,80,40);

      //Evento del Boton OK
      btnx3.addActionListener(new ActionListener(){
      public void actionPerformed( ActionEvent ev ){
        for(int i=0;i<1;i++)
        //Enviar un Mensaje
        JOptionPane.showMessageDialog(null,"Hola otra vez xD","Mensaje" , JOptionPane.INFORMATION_MESSAGE);
      }});

      //Evento del Boton SALIR
      btnx4.addActionListener(new ActionListener(){
      public void actionPerformed( ActionEvent ev ){
        for(int i=0;i<1;i++)
          //Enviar un Mensaje
          JOptionPane.showMessageDialog(null,"Consulta el checkbox de texto xD","Mensaje" , JOptionPane.INFORMATION_MESSAGE);
      }});
      //Agregamos los Componetes a la ventana1
      ventana1.add(txt2);
      ventana1.add(et2);
      ventana1.add(btnx3);
      ventana1.add(btnx4);
      ventana1.setVisible(true);
      }
    }

    //---------------------------------------------------------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------------------------------------------------------
    //Aqui Termina la creacion de las Ventanas que se generan al dar clic en el Boton Dialogo



    //"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    //"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    // Esta se encarga de Realizar la Invocacion de los metodos Decuerdo al el Boton que a sido Seleccionado.

    //Clase Eventos
    public class Eventos implements ActionListener{

        public void actionPerformed(ActionEvent e){
            Object src=e.getSource();
            if(src.equals(btn1)){
              VentanaPatron();
            }

            if(src.equals(btn2)){
              new LienzoIm();
            }
            if(src.equals(btn3)){
              Ventana3();

            }
        }

      }

      //"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
      //"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
      // Esta se encarga de Realizar la Invocacion de los metodos Decuerdo al el Boton que a sido Seleccionado.


}//Ventanas
