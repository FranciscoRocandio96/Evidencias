//Nombre del paquete donde estan todos los codigos
package Farmacia;
//Scanner
import java.util.Scanner;
//Clase medicamento
public class Medicamento{
    //Atributos
    private int idMedicament;
    private String nomFarmaco;
    private float costo;

    //Constructor
    public Medicamento(){
        costo=250f;
        nomFarmaco= "Paracetamol";
    }

    //Setters
    public void setidMedicament( int id){
        idMedicament=id;
    }
    public void setNomFarmaco( String e){
        this.nomFarmaco=e;
    }
    public void setCosto( float c){
        costo=c;
    }

    //Getters
    public int getidMedicament(){
        return idMedicament;
    }
    public String getNomFarmaco(){
        return nomFarmaco;
    }
    public float getCosto(){
        return costo;
    }

    //Metodo toString
    public String toString(){
        String var= "\nId del Medicamento: "+ getidMedicament();
        var+= "\nNombre del Farmaco: "+ getNomFarmaco();
        var+= "\nCosto: "+ getCosto();
        return var;
    }//toString

    //Metodo para pedir datos de medicamento
    public void datosMedicamento(){
        Scanner x= new Scanner(System.in);
        System.out.println("\n Ingresa los datos del Medicamento: ");
        System.out.println("\n Id Medicamento: ");
        setidMedicament(x.nextInt()); x.nextLine();
        System.out.println("\n Nombre del Farmaco: ");
        setNomFarmaco(x.nextLine());
        System.out.println("\n Costo del Medicamento: ");
        setCosto(x.nextFloat());
    }//datosMedicamento

}//clase Medicamento
