//Nombre del paquete donde estan todos los codigos
package Farmacia;
//Clase para utilizar arreglos
import java.util.Arrays;
//Clase principal
public class Principal{
    //clase del metodo main
    public static void main ( String [] args){
    //Creamos los 2 objetos de la clase Doctor
    Doctor x= new Doctor();
    Doctor y= new Doctor();
    //Creamos el objeto de la clase Medicamento
    Medicamento z= new Medicamento();

    //Pedimos e imprimimos los datos de cada Objeto
    x.datosDoctor();
    System.out.println(x);

    y.datosDoctor();
    System.out.println(y);

    z.datosMedicamento();
    System.out.println(z);

    //Creamos un arreglo de tipo Medicamento de 50 medicamentos
    Medicamento[] arr= new Medicamento[50];
    //Creamos 3 medicamentos
    arr[0] =new Medicamento();
    arr[1] =new Medicamento();
    arr[2] =new Medicamento();
    //Usamos un for para crear los 47 medicamentos restantes
    for( int i=3;i<50;i++){
        arr[i] =new Medicamento();
    }

    for( int i=0;i<3;i++){
        //Pedimos los datos de los 3 medicamentos creados
        arr[i].datosMedicamento();
    }

     for( int i=0;i<10;i++){
       //Imprimimos hasta el indice 10 en el arreglo de Medicamento
        System.out.println(arr[i]);
    }

    //Creamos un arreglo de tipo Doctor
    Doctor[] arr2= new Doctor[10];
	  int cedula=2345;
	  for( int i=0;i<10;i++){
    //Creamos los 10 Doctores
		arr2[i] =new Doctor();
    }

    for (int i=0; i<arr2.length;i++) {
    //Incrementamos el numero de cedula
    int ced=cedula++;
		arr2[i].setCedula(ced);
	}

	   for( int i=0;i<10;i++){
     //Imprimimos el arreglo de Doctor
     System.out.println(arr2[i]);
    }
	   System.out.println("\n");
     //Creamos el segundo arreglo de tipo Doctor
	   Doctor[] array= new Doctor[10];
	   int cedu=1029;

	   for( int i=0;i<10;i++){
     //Creamos los 10 Doctores
		 array[i] =new Doctor();
     }

	  for (int i=0; i<arr2.length;i++) {
		int cedl=cedu++;
    //Incrementamos el numero de cedula y la asignamos al Doctor
		array[i].setCedula(cedl);
	  }
	  for( int i=0;i<10;i++){
    //Imprimimos los 10 Doctores
    System.out.println(array[i]);
	  }

 }//Main

}//clase Principal
