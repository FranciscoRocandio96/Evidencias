//Nombre del paquete donde estan todos los codigos
package Farmacia;
//Scanner
import java.util.Scanner;

//Clase Doctor
public class Doctor{


    //Atributos
    private String nombre, especialidad;
    private int cedula,idMedic;
    private float precioC;

    //Constructor
    public Doctor(){
        //Constructor
        nombre="Hernandez";
		     precioC=250f;
        especialidad= "Pediatra";


    }
      //Constructor que recibe todos los atributos por parametro
	public Doctor(String n, int ced,String espe,float pre){
		nombre=n;
		cedula=ced;
		espe= "Cirujano";
		especialidad=espe;
		pre=60f;
		precioC=pre;
    }

    // Setters
    public void setNombre( String nombre){
        this.nombre=nombre;
    }
    public void setEspecialidad( String e){
        this.especialidad=e;
    }
    public void setCedula( int c){
        cedula=c;
    }
    public void setIdMedic (int id){
        idMedic=id;
    }
    public void setPrecioC( float p){
        precioC=p;
    }

    //Getters
    public String getNombre(){
        return nombre;
    }
    public String getEspecialidad(){
        return especialidad;
    }
    public int getCedula(){
        return cedula;
    }
    public int getIdMedic(){
        return idMedic;
    }
    public float getPrecioC(){
        return precioC;
    }

    //Metodo toString
    public String toString(){
        String var= "\nDoctor: "+ getNombre();
        var+= "\nCedula: "+ getCedula();
        var+= "\nEspecialidad: "+ getEspecialidad();
        var+= "\nPrecio Consulta: "+ getPrecioC();
        return var;

    }//toString

    //Metodo para pedir datos
    public void datosDoctor(){
        Scanner x= new Scanner(System.in);
        System.out.println("\n Ingresa los datos del doctor: ");
        System.out.println("\n Nombre: ");
        setNombre(x.nextLine());
        System.out.println("\n Especialidad: ");
        setEspecialidad(x.nextLine());
        System.out.println("\n Numero de Cedula: ");
        setCedula(x.nextInt());
        System.out.println("\n Costo de consulta: ");
        setPrecioC(x.nextFloat());
    }//datosDoctor




}//clase Doctor
