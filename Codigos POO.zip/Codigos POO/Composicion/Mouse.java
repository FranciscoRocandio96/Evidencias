//Paquete
package Composicion;
//Scanner
import java.util.Scanner;
//Clase Mouse
public class Mouse{
    //Atributos
    private String marca, tamanio;

    //Metodo pedirDatos
    public void pedirDatos(){
        Scanner x = new Scanner(System.in);
        System.out.println("\nMouse: \nMarca: ");
        marca = x.nextLine();
        System.out.println("\nTamanio: ");
        tamanio = x.nextLine();
    }

    //Metodo toString
    public String toString(){
        String s = "\nMouse: " + marca;
        s+= "\nTamanio: " + tamanio + "\n";
        return s;
    }
}
