//Paquete
package Composicion;
//Clase Principal
public class Principal{
  //Metodo main
  public static void main(String[] args){
    //Creamos un objeto de Computadora
    Computadora c = new Computadora();
    //Pedimos e imprimimos sus Datos y verificamos la Composicion
    c.pedirDatos();
    System.out.println(c);

  }//main

}//principal
