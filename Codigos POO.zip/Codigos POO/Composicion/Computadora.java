//Paquete
package Composicion;
//Scanner
import java.util.Scanner;
//Clase Computadora
public class Computadora{

    //Atributos
    private String tipo;
    private int disco;
    //Variable de Composicion
    private Mouse m;

    //Constructor creando un objeto de Mouse
    public Computadora(){
       m = new Mouse();
    }

    //Metodo pedirDatos
    public void pedirDatos(){
        Scanner l = new Scanner(System.in);
        System.out.println("\nTipo de computadora: ");
        tipo = l.nextLine();
        System.out.println("\nCapacidad de disco: ");
        disco = l.nextInt();
        //Pedimos los datos del objeto de la Composicion
        m.pedirDatos();
    }

    //MEtodo toString
    public String toString(){
        String cad = "\nComputadora: " + tipo;
        cad += "\nDisco Duro: " + disco;
        //Concatenamos el Metodo toString del objeto que forma parte la de composicion
        cad += m.toString();
        return cad;
    }
}
