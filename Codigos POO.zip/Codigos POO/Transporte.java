//Importamos la clase Scanner.
import java.util.Scanner;
//Creamos la clase principal
public class Transporte{
	//Atributos
	private String tipo;
	private float velocidad;
	private int pasajeros;
	//Metodos

	//Metodo setTransporte para pedir los datos.
	public void setTransporte(){
		Scanner lee = new Scanner(System.in);
		System.out.print("\nIngresa el tipo de transporte: ");
		tipo = lee.nextLine();
		System.out.print("Ingresa su velocidad en Km/h: ");
		velocidad = lee.nextFloat();
		System.out.print("Cantidad de Pasajeros: ");
		pasajeros = lee.nextInt();
	}//setTransporte

	//El metodo toString sirve para representar un Objeto como una cadena de caracteres.
	public String toString(){
		String transporte= new String();
		transporte="\nTipo: "+tipo+"\nVelocidad: "+velocidad+"\nPasajeros: "+pasajeros;
		System.out.println("\n "+transporte);
		return transporte;
	}//toString

	//Metodo calcTiempo con este metodo calculamos el tiempo que tarda el rrecorrido del auto
	public float calcTiempo(float dis){
		float tim;
		tim=(dis/velocidad);
		System.out.println("El tiempo de trayecto es de :" + tim+"h");
		return tim;
	}//calcTiempo

	//Creamos la clase del metodo main.
	 public static void main(String[] args){

		 //Creamos un objeto de la clase principal
		Transporte x = new Transporte();
		//pedirmos y imprimimos los datos.
		x.setTransporte();
		x.toString();

		//Creamos el Objeto de tipo Scanner
		Scanner lee = new Scanner(System.in);
		System.out.print("Ingresa la distancia recorrida en Km: ");
		float dis = lee.nextFloat();
		  x.calcTiempo(dis);
	 }//Main

}//clase
